import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'ads/ad_manager.dart';
import 'constants.dart';
import 'providers/status_provider.dart';
import 'screens/home_screen.dart';
import 'screens/permission_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AdManager.initialize();
  runApp(const StatusSaverApp());
}

class StatusSaverApp extends StatelessWidget {
  const StatusSaverApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => StatusProvider(),
      child: MaterialApp(
        title: AppConstants.appName,
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF25D366)),
          useMaterial3: true,
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF25D366),
            foregroundColor: Colors.white,
          ),
          tabBarTheme: const TabBarTheme(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF25D366),
              foregroundColor: Colors.white,
            ),
          ),
        ),
        initialRoute: AppConstants.routeHome,
        routes: {
          AppConstants.routeHome: (_) => const HomeScreen(),
          AppConstants.routePermission: (_) => const PermissionScreen(),
        },
      ),
    );
  }
}
