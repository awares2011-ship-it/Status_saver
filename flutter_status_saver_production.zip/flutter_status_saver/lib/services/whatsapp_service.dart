import 'dart:io';
import 'package:flutter/foundation.dart';
import '../constants.dart';

enum StatusType { image, video }

class StatusFile {
  final File file;
  final StatusType type;
  final DateTime modifiedAt;

  const StatusFile({
    required this.file,
    required this.type,
    required this.modifiedAt,
  });

  String get path => file.path;
  String get name => file.uri.pathSegments.last;
  bool get isImage => type == StatusType.image;
  bool get isVideo => type == StatusType.video;
}

class WhatsAppService {
  static List<StatusFile>? _cachedStatuses;
  static DateTime? _lastScanTime;
  static int? _lastFileCount;

  static const Duration _cacheValidDuration = Duration(minutes: 1);

  static Future<List<StatusFile>> loadStatuses({bool forceRefresh = false}) async {
    try {
      final now = DateTime.now();
      if (!forceRefresh && _cachedStatuses != null && _lastScanTime != null) {
        final age = now.difference(_lastScanTime!);
        if (age < _cacheValidDuration) {
          return _cachedStatuses!;
        }
      }

      final statuses = await compute(_scanAllStatusDirectories, [
        AppConstants.whatsappStatusPath,
        AppConstants.whatsappBusinessStatusPath,
      ]);

      if (!forceRefresh &&
          _cachedStatuses != null &&
          statuses.length == (_lastFileCount ?? -1)) {
        _lastScanTime = now;
        return _cachedStatuses!;
      }

      _cachedStatuses = statuses;
      _lastScanTime = now;
      _lastFileCount = statuses.length;
      return statuses;
    } catch (e) {
      debugPrint('WhatsAppService.loadStatuses error: $e');
      return _cachedStatuses ?? [];
    }
  }

  static Future<List<StatusFile>> _scanAllStatusDirectories(List<String> paths) async {
    final results = <StatusFile>[];
    for (final path in paths) {
      try {
        final dir = Directory(path);
        if (!await dir.exists()) continue;
        await for (final entity in dir.list()) {
          if (entity is File) {
            final statusFile = _toStatusFile(entity);
            if (statusFile != null) {
              results.add(statusFile);
            }
          }
        }
      } catch (e) {
        debugPrint('_scanAllStatusDirectories error for $path: $e');
      }
    }
    results.sort((a, b) => b.modifiedAt.compareTo(a.modifiedAt));
    return results;
  }

  static StatusFile? _toStatusFile(File file) {
    try {
      final name = file.uri.pathSegments.last.toLowerCase();
      if (name.startsWith('.')) return null;

      StatusType? type;
      for (final ext in AppConstants.imageExtensions) {
        if (name.endsWith(ext)) {
          type = StatusType.image;
          break;
        }
      }
      if (type == null) {
        for (final ext in AppConstants.videoExtensions) {
          if (name.endsWith(ext)) {
            type = StatusType.video;
            break;
          }
        }
      }
      if (type == null) return null;

      final stat = file.statSync();
      return StatusFile(
        file: file,
        type: type,
        modifiedAt: stat.modified,
      );
    } catch (e) {
      debugPrint('_toStatusFile error: $e');
      return null;
    }
  }

  static Future<bool> saveStatus(StatusFile statusFile) async {
    try {
      final saveDir = Directory(
        '/storage/emulated/0/Pictures/${AppConstants.savedStatusDir}',
      );
      if (!await saveDir.exists()) {
        await saveDir.create(recursive: true);
      }
      final dest = File('${saveDir.path}/${statusFile.name}');
      await statusFile.file.copy(dest.path);
      return true;
    } catch (e) {
      debugPrint('WhatsAppService.saveStatus error: $e');
      return false;
    }
  }

  static Future<List<StatusFile>> loadSavedStatuses() async {
    try {
      final saveDir = Directory(
        '/storage/emulated/0/Pictures/${AppConstants.savedStatusDir}',
      );
      if (!await saveDir.exists()) return [];

      final results = <StatusFile>[];
      await for (final entity in saveDir.list()) {
        if (entity is File) {
          final statusFile = _toStatusFile(entity);
          if (statusFile != null) results.add(statusFile);
        }
      }
      results.sort((a, b) => b.modifiedAt.compareTo(a.modifiedAt));
      return results;
    } catch (e) {
      debugPrint('WhatsAppService.loadSavedStatuses error: $e');
      return [];
    }
  }

  static void invalidateCache() {
    _cachedStatuses = null;
    _lastScanTime = null;
    _lastFileCount = null;
  }
}
