import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

enum PermissionState { granted, denied, permanentlyDenied, unknown }

class PermissionUtils {
  PermissionUtils._();

  static Future<PermissionState> checkStoragePermission() async {
    try {
      final sdkInt = await _getAndroidSdkVersion();

      if (sdkInt >= 33) {
        final images = await Permission.photos.status;
        final videos = await Permission.videos.status;
        if (images.isGranted && videos.isGranted) return PermissionState.granted;
        if (images.isPermanentlyDenied || videos.isPermanentlyDenied) {
          return PermissionState.permanentlyDenied;
        }
        return PermissionState.denied;
      } else {
        final status = await Permission.storage.status;
        if (status.isGranted) return PermissionState.granted;
        if (status.isPermanentlyDenied) return PermissionState.permanentlyDenied;
        return PermissionState.denied;
      }
    } catch (e) {
      debugPrint('PermissionUtils.checkStoragePermission error: $e');
      return PermissionState.unknown;
    }
  }

  static Future<PermissionState> requestStoragePermission() async {
    try {
      final sdkInt = await _getAndroidSdkVersion();

      if (sdkInt >= 33) {
        final statuses = await [Permission.photos, Permission.videos].request();
        final images = statuses[Permission.photos];
        final videos = statuses[Permission.videos];
        if (images!.isGranted && videos!.isGranted) return PermissionState.granted;
        if (images.isPermanentlyDenied || videos!.isPermanentlyDenied) {
          return PermissionState.permanentlyDenied;
        }
        return PermissionState.denied;
      } else {
        final status = await Permission.storage.request();
        if (status.isGranted) return PermissionState.granted;
        if (status.isPermanentlyDenied) return PermissionState.permanentlyDenied;
        return PermissionState.denied;
      }
    } catch (e) {
      debugPrint('PermissionUtils.requestStoragePermission error: $e');
      return PermissionState.unknown;
    }
  }

  static Future<void> openAppSettings() async {
    try {
      await openAppSettings();
    } catch (e) {
      debugPrint('PermissionUtils.openAppSettings error: $e');
    }
  }

  static Future<int> _getAndroidSdkVersion() async {
    try {
      final info = await _platformSdkInt();
      return info;
    } catch (_) {
      return 0;
    }
  }

  static Future<int> _platformSdkInt() async {
    try {
      const platform = MethodChannel('status_saver/platform');
      final result = await platform.invokeMethod<int>('getSdkInt');
      return result ?? 0;
    } catch (_) {
      return 0;
    }
  }
}

import 'package:flutter/services.dart';
