import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../ads/ad_manager.dart';
import '../constants.dart';
import '../providers/status_provider.dart';
import '../services/whatsapp_service.dart';
import '../utils/permission_utils.dart';
import '../widgets/status_grid.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkPermissionAndLoad();
    });
  }

  Future<void> _checkPermissionAndLoad() async {
    final provider = context.read<StatusProvider>();
    await provider.checkPermission();
    if (provider.permissionState != PermissionState.granted) {
      if (!mounted) return;
      Navigator.of(context).pushReplacementNamed(AppConstants.routePermission);
    }
  }

  Future<void> _onSave(StatusFile status) async {
    final provider = context.read<StatusProvider>();
    final success = await provider.saveStatus(status);
    AdManager.trackAction();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          success ? AppConstants.savedSuccessMessage : AppConstants.saveFailedMessage,
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  Future<void> _onShare(StatusFile status) async {
    try {
      AdManager.trackAction();
      await Share.shareXFiles([XFile(status.path)]);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text(AppConstants.shareFailedMessage)),
      );
    }
  }

  void _onPreview(StatusFile status) {
    AdManager.trackAction();
    Navigator.of(context).pushNamed(AppConstants.routePreview, arguments: status);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName),
        elevation: 0,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: AppConstants.tabImages),
            Tab(text: AppConstants.tabVideos),
            Tab(text: AppConstants.tabSaved),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Consumer<StatusProvider>(
              builder: (context, provider, _) {
                if (provider.hasError) {
                  return _ErrorState(
                    message: provider.errorMessage ?? 'Something went wrong.',
                    onRetry: provider.refresh,
                  );
                }
                return RefreshIndicator(
                  onRefresh: provider.refresh,
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      StatusGrid(
                        statuses: provider.images,
                        isLoading: provider.isLoading,
                        onTap: _onPreview,
                        onSave: _onSave,
                        onShare: _onShare,
                      ),
                      StatusGrid(
                        statuses: provider.videos,
                        isLoading: provider.isLoading,
                        onTap: _onPreview,
                        onSave: _onSave,
                        onShare: _onShare,
                      ),
                      StatusGrid(
                        statuses: provider.saved,
                        isLoading: provider.isLoading,
                        onTap: _onPreview,
                        onSave: _onSave,
                        onShare: _onShare,
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          const BannerAdWidget(),
        ],
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const _ErrorState({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 64, color: Colors.red.shade300),
            const SizedBox(height: 16),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text(AppConstants.btnRetry),
            ),
          ],
        ),
      ),
    );
  }
}
