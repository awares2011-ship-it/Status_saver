import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart' as ph;
import 'package:provider/provider.dart';
import '../constants.dart';
import '../providers/status_provider.dart';
import '../utils/permission_utils.dart';

class PermissionScreen extends StatefulWidget {
  const PermissionScreen({super.key});

  @override
  State<PermissionScreen> createState() => _PermissionScreenState();
}

class _PermissionScreenState extends State<PermissionScreen> {
  bool _isRequesting = false;

  Future<void> _requestPermission() async {
    if (_isRequesting) return;
    setState(() => _isRequesting = true);

    final provider = context.read<StatusProvider>();
    final result = await provider.requestPermission();

    if (!mounted) return;
    setState(() => _isRequesting = false);

    if (result == PermissionState.granted) {
      Navigator.of(context).pushReplacementNamed(AppConstants.routeHome);
    } else if (result == PermissionState.permanentlyDenied) {
      _showPermanentlyDeniedDialog();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text(AppConstants.permissionDeniedMessage)),
      );
    }
  }

  Future<void> _openSettings() async {
    await ph.openAppSettings();
  }

  void _showPermanentlyDeniedDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text(AppConstants.permissionRationaleTitle),
        content: const Text(
          'You have permanently denied storage permission. '
          'Please open Settings and grant access manually.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(ctx);
              _openSettings();
            },
            child: const Text(AppConstants.btnOpenSettings),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final permissionState = context.watch<StatusProvider>().permissionState;
    final isPermanentlyDenied = permissionState == PermissionState.permanentlyDenied;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              Icon(
                Icons.folder_open_rounded,
                size: 100,
                color: Theme.of(context).primaryColor,
              ),
              const SizedBox(height: 32),
              Text(
                AppConstants.permissionRationaleTitle,
                style: Theme.of(context)
                    .textTheme
                    .headlineSmall
                    ?.copyWith(fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Text(
                AppConstants.permissionRationaleBody,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 15, color: Colors.grey.shade600, height: 1.5),
              ),
              const Spacer(),
              if (isPermanentlyDenied) ...[
                _PrimaryButton(
                  label: AppConstants.btnOpenSettings,
                  onPressed: _openSettings,
                  isLoading: false,
                ),
              ] else ...[
                _PrimaryButton(
                  label: AppConstants.btnGrantPermission,
                  onPressed: _requestPermission,
                  isLoading: _isRequesting,
                ),
              ],
              const SizedBox(height: 16),
              if (isPermanentlyDenied)
                TextButton(
                  onPressed: _requestPermission,
                  child: const Text(AppConstants.btnRetry),
                ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  final bool isLoading;

  const _PrimaryButton({
    required this.label,
    required this.onPressed,
    required this.isLoading,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
        child: isLoading
            ? const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
              )
            : Text(label, style: const TextStyle(fontSize: 16)),
      ),
    );
  }
}
