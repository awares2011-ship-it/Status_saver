import 'package:flutter/material.dart';
import '../services/whatsapp_service.dart';
import '../utils/permission_utils.dart';

enum LoadingState { idle, loading, loaded, error }

class StatusProvider extends ChangeNotifier with WidgetsBindingObserver {
  List<StatusFile> _images = [];
  List<StatusFile> _videos = [];
  List<StatusFile> _saved = [];

  LoadingState _loadingState = LoadingState.idle;
  PermissionState _permissionState = PermissionState.unknown;
  String? _errorMessage;
  bool _isRefreshing = false;

  List<StatusFile> get images => _images;
  List<StatusFile> get videos => _videos;
  List<StatusFile> get saved => _saved;
  LoadingState get loadingState => _loadingState;
  PermissionState get permissionState => _permissionState;
  String? get errorMessage => _errorMessage;
  bool get isRefreshing => _isRefreshing;
  bool get isLoading => _loadingState == LoadingState.loading || _isRefreshing;
  bool get hasError => _loadingState == LoadingState.error;

  StatusProvider() {
    WidgetsBinding.instance.addObserver(this);
    _initialize();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      refresh();
    }
  }

  Future<void> _initialize() async {
    await checkPermission();
    if (_permissionState == PermissionState.granted) {
      await _load();
    }
  }

  Future<void> checkPermission() async {
    _permissionState = await PermissionUtils.checkStoragePermission();
    notifyListeners();
  }

  Future<PermissionState> requestPermission() async {
    _permissionState = await PermissionUtils.requestStoragePermission();
    notifyListeners();
    if (_permissionState == PermissionState.granted) {
      await _load();
    }
    return _permissionState;
  }

  Future<void> _load({bool forceRefresh = false}) async {
    if (_loadingState == LoadingState.loading && !forceRefresh) return;

    _loadingState = LoadingState.loading;
    _errorMessage = null;
    notifyListeners();

    try {
      final statuses = await WhatsAppService.loadStatuses(forceRefresh: forceRefresh);
      final savedStatuses = await WhatsAppService.loadSavedStatuses();

      _images = statuses.where((s) => s.isImage).toList();
      _videos = statuses.where((s) => s.isVideo).toList();
      _saved = savedStatuses;

      _loadingState = LoadingState.loaded;
    } catch (e) {
      _loadingState = LoadingState.error;
      _errorMessage = 'Failed to load statuses. Please try again.';
      debugPrint('StatusProvider._load error: $e');
    } finally {
      notifyListeners();
    }
  }

  Future<void> refresh() async {
    if (_isRefreshing) return;
    if (_permissionState != PermissionState.granted) {
      await checkPermission();
      if (_permissionState != PermissionState.granted) return;
    }
    _isRefreshing = true;
    notifyListeners();
    WhatsAppService.invalidateCache();
    await _load(forceRefresh: true);
    _isRefreshing = false;
    notifyListeners();
  }

  Future<bool> saveStatus(StatusFile statusFile) async {
    try {
      final success = await WhatsAppService.saveStatus(statusFile);
      if (success) {
        final savedStatuses = await WhatsAppService.loadSavedStatuses();
        _saved = savedStatuses;
        notifyListeners();
      }
      return success;
    } catch (e) {
      debugPrint('StatusProvider.saveStatus error: $e');
      return false;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }
}
