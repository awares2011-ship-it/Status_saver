import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../constants.dart';

class AdManager {
  AdManager._();

  static InterstitialAd? _interstitialAd;
  static bool _isInterstitialLoading = false;
  static int _actionCount = 0;
  static DateTime? _lastInterstitialShownAt;

  static bool get isInterstitialReady => _interstitialAd != null;

  static Future<void> initialize() async {
    try {
      await MobileAds.instance.initialize();
      _preloadInterstitial();
    } catch (e) {
      debugPrint('AdManager.initialize error: $e');
    }
  }

  static BannerAd createBannerAd() {
    return BannerAd(
      adUnitId: AppConstants.activeBannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdFailedToLoad: (ad, error) {
          debugPrint('BannerAd failed: $error');
          ad.dispose();
        },
      ),
    );
  }

  static void _preloadInterstitial() {
    if (_isInterstitialLoading || _interstitialAd != null) return;
    _isInterstitialLoading = true;

    InterstitialAd.load(
      adUnitId: AppConstants.activeInterstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          _isInterstitialLoading = false;
          _interstitialAd!.setImmersiveMode(true);
          debugPrint('InterstitialAd loaded');
        },
        onAdFailedToLoad: (error) {
          _isInterstitialLoading = false;
          debugPrint('InterstitialAd failed to load: $error');
          Future.delayed(const Duration(seconds: 30), _preloadInterstitial);
        },
      ),
    );
  }

  static void trackAction() {
    _actionCount++;
    if (_actionCount >= AppConstants.adInterstitialFrequency) {
      _actionCount = 0;
      _tryShowInterstitial();
    }
  }

  static void _tryShowInterstitial() {
    final now = DateTime.now();
    if (_lastInterstitialShownAt != null) {
      final elapsed = now.difference(_lastInterstitialShownAt!);
      if (elapsed < AppConstants.adInterstitialCooldown) return;
    }
    showInterstitial();
  }

  static Future<void> showInterstitial({VoidCallback? onDismissed}) async {
    if (_interstitialAd == null) {
      debugPrint('AdManager: No interstitial ready');
      onDismissed?.call();
      _preloadInterstitial();
      return;
    }

    _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _interstitialAd = null;
        _lastInterstitialShownAt = DateTime.now();
        _preloadInterstitial();
        onDismissed?.call();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _interstitialAd = null;
        debugPrint('InterstitialAd failed to show: $error');
        _preloadInterstitial();
        onDismissed?.call();
      },
    );

    try {
      await _interstitialAd!.show();
    } catch (e) {
      debugPrint('AdManager.showInterstitial error: $e');
      _interstitialAd?.dispose();
      _interstitialAd = null;
      onDismissed?.call();
    }
  }

  static void dispose() {
    _interstitialAd?.dispose();
    _interstitialAd = null;
  }
}

class BannerAdWidget extends StatefulWidget {
  const BannerAdWidget({super.key});

  @override
  State<BannerAdWidget> createState() => _BannerAdWidgetState();
}

class _BannerAdWidgetState extends State<BannerAdWidget> {
  BannerAd? _bannerAd;
  bool _isLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadBanner();
  }

  void _loadBanner() {
    final ad = AdManager.createBannerAd();
    ad.load().then((_) {
      if (mounted) {
        setState(() {
          _bannerAd = ad;
          _isLoaded = true;
        });
      }
    }).catchError((e) {
      debugPrint('BannerAdWidget load error: $e');
    });
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_isLoaded || _bannerAd == null) return const SizedBox.shrink();
    return SizedBox(
      height: _bannerAd!.size.height.toDouble(),
      width: _bannerAd!.size.width.toDouble(),
      child: AdWidget(ad: _bannerAd!),
    );
  }
}
