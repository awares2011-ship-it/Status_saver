import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
import '../services/whatsapp_service.dart';
import '../constants.dart';

class StatusGrid extends StatelessWidget {
  final List<StatusFile> statuses;
  final bool isLoading;
  final void Function(StatusFile) onTap;
  final void Function(StatusFile) onSave;
  final void Function(StatusFile) onShare;

  const StatusGrid({
    super.key,
    required this.statuses,
    required this.isLoading,
    required this.onTap,
    required this.onSave,
    required this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    if (isLoading) return const _ShimmerGrid();
    if (statuses.isEmpty) return const _EmptyState();

    return GridView.builder(
      padding: const EdgeInsets.all(8),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 6,
        mainAxisSpacing: 6,
      ),
      itemCount: statuses.length,
      itemBuilder: (context, index) {
        final status = statuses[index];
        return _StatusTile(
          status: status,
          onTap: () => onTap(status),
          onSave: () => onSave(status),
          onShare: () => onShare(status),
        );
      },
    );
  }
}

class _StatusTile extends StatelessWidget {
  final StatusFile status;
  final VoidCallback onTap;
  final VoidCallback onSave;
  final VoidCallback onShare;

  const _StatusTile({
    required this.status,
    required this.onTap,
    required this.onSave,
    required this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Stack(
        fit: StackFit.expand,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: status.isVideo
                ? _VideoThumbnail(file: status.file)
                : Image.file(
                    status.file,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: Colors.grey.shade200,
                      child: const Icon(Icons.broken_image, color: Colors.grey),
                    ),
                  ),
          ),
          if (status.isVideo)
            const Positioned(
              top: 4,
              left: 4,
              child: Icon(Icons.play_circle_filled, color: Colors.white, size: 24),
            ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Colors.black54, Colors.transparent],
                ),
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(8)),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  _IconBtn(icon: Icons.download, onTap: onSave),
                  const SizedBox(width: 4),
                  _IconBtn(icon: Icons.share, onTap: onShare),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _IconBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _IconBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Icon(icon, color: Colors.white, size: 20),
    );
  }
}

class _VideoThumbnail extends StatelessWidget {
  final File file;
  const _VideoThumbnail({required this.file});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black87,
      child: const Center(
        child: Icon(Icons.videocam, color: Colors.white54, size: 40),
      ),
    );
  }
}

class _ShimmerGrid extends StatelessWidget {
  const _ShimmerGrid();

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey.shade300,
      highlightColor: Colors.grey.shade100,
      child: GridView.builder(
        padding: const EdgeInsets.all(8),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 6,
          mainAxisSpacing: 6,
        ),
        itemCount: 12,
        itemBuilder: (_, __) => ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Container(color: Colors.white),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.photo_library_outlined, size: 80, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Text(
            AppConstants.noStatusesMessage,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 16, color: Colors.grey.shade600, height: 1.5),
          ),
        ],
      ),
    );
  }
}
