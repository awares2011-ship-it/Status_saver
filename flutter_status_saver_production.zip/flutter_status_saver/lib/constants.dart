class AppConstants {
  AppConstants._();

  static const String appName = 'Status Saver for WhatsApp';

  static const String whatsappStatusPath =
      '/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/.Statuses';
  static const String whatsappBusinessStatusPath =
      '/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses';

  static const String savedStatusDir = 'StatusSaver';

  static const List<String> imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
  static const List<String> videoExtensions = ['.mp4', '.mkv', '.avi', '.3gp', '.mov'];

  static const int adInterstitialFrequency = 3;
  static const int adBannerReloadDelaySeconds = 60;
  static const Duration adInterstitialCooldown = Duration(seconds: 30);

  static const String permissionRationaleTitle = 'Storage Permission Required';
  static const String permissionRationaleBody =
      'This app needs access to your storage to read and save WhatsApp statuses. '
      'Your files are never uploaded or shared.';
  static const String permissionDeniedMessage =
      'Permission denied. Please grant storage access in Settings.';
  static const String noStatusesMessage = 'No statuses found.\nAsk your contacts to post some!';
  static const String savedSuccessMessage = 'Status saved successfully!';
  static const String saveFailedMessage = 'Failed to save status. Please try again.';
  static const String shareFailedMessage = 'Could not share status.';

  static const String tabImages = 'Images';
  static const String tabVideos = 'Videos';
  static const String tabSaved = 'Saved';

  static const String btnGrantPermission = 'Grant Permission';
  static const String btnOpenSettings = 'Open Settings';
  static const String btnRetry = 'Retry';
  static const String btnSave = 'Save';
  static const String btnShare = 'Share';

  static const String routeHome = '/';
  static const String routePermission = '/permission';
  static const String routePreview = '/preview';

  static const String adBannerUnitId = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';
  static const String adInterstitialUnitId = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';
  static const String adTestBannerUnitId = 'ca-app-pub-3940256099942544/6300978111';
  static const String adTestInterstitialUnitId = 'ca-app-pub-3940256099942544/1033173712';

  static const bool useTestAds = true;

  static String get activeBannerAdUnitId =>
      useTestAds ? adTestBannerUnitId : adBannerUnitId;

  static String get activeInterstitialAdUnitId =>
      useTestAds ? adTestInterstitialUnitId : adInterstitialUnitId;
}
