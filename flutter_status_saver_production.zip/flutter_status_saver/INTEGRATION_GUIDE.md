# Integration Guide — Status Saver Production Upgrade

This guide explains how to integrate each file into your existing Flutter project.

---

## Step 1 — Copy Files

Copy these files into your existing project's `lib/` folder:

```
lib/constants.dart                    → Replace or merge with your existing constants
lib/services/whatsapp_service.dart    → Replace existing whatsapp/file service
lib/providers/status_provider.dart    → Replace existing provider
lib/utils/permission_utils.dart       → Replace existing permission handling
lib/ads/ad_manager.dart               → Replace existing ad manager
lib/widgets/status_grid.dart          → Add to widgets folder
lib/screens/home_screen.dart          → Replace existing home screen
lib/screens/permission_screen.dart    → Add new screen
lib/main.dart                         → Update your main.dart
```

---

## Step 2 — Update pubspec.yaml

Add these dependencies if not already present:

```yaml
dependencies:
  provider: ^6.1.2
  permission_handler: ^11.3.1
  google_mobile_ads: ^5.1.0
  share_plus: ^9.0.0
  shimmer: ^3.0.0
```

Run: `flutter pub get`

---

## Step 3 — Replace AndroidManifest.xml permissions

Copy the permissions block from `android/app/src/main/AndroidManifest.xml` into your manifest.

**Replace the AdMob App ID placeholder:**
```xml
android:value="ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX"
```
With your real AdMob App ID from the AdMob dashboard.

---

## Step 4 — Replace Ad Unit IDs

In `lib/constants.dart`, replace the placeholder IDs:

```dart
static const String adBannerUnitId = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';
static const String adInterstitialUnitId = 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX';
```

Set `useTestAds = false` for production builds.

---

## Step 5 — Android SDK Version Channel (for Android 13+ permission split)

Add this to your `MainActivity.kt` / `MainActivity.java`:

### Kotlin (MainActivity.kt)
```kotlin
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "status_saver/platform"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method == "getSdkInt") {
                    result.success(android.os.Build.VERSION.SDK_INT)
                } else {
                    result.notImplemented()
                }
            }
    }
}
```

---

## Step 6 — ProGuard rules (release builds)

Add to `android/app/proguard-rules.pro`:

```
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.ads.** { *; }
```

---

## What Each File Does

| File | Purpose |
|------|---------|
| `constants.dart` | All strings, paths, and config — no magic strings |
| `whatsapp_service.dart` | Async file scanning, caching, save logic — crash-safe |
| `status_provider.dart` | State management, lifecycle observer, permission integration |
| `permission_utils.dart` | Android 8–14+ permission handling, permanently denied flow |
| `ad_manager.dart` | AdMob banner + interstitial with preloading, frequency caps |
| `status_grid.dart` | Grid UI with shimmer loader, empty state, video badges |
| `home_screen.dart` | Pull-to-refresh, tabs (Images/Videos/Saved), banner ad footer |
| `permission_screen.dart` | Dedicated permission rationale screen with all states |
| `main.dart` | App entry point, Provider setup, routes, theme |

---

## Crash Prevention Summary

All crash vectors are handled:

- File scanning uses `compute()` (background isolate) — never blocks UI
- All file ops wrapped in `try-catch`
- Permission states fully handled (granted / denied / permanently denied)
- Ad failures never crash the app — UX continues normally
- Cache invalidation prevents stale state
- Lifecycle observer auto-refreshes without duplicate calls
- `WidgetsBinding.instance.addPostFrameCallback` prevents white screen on launch
