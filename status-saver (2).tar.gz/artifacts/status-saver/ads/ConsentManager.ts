/**
 * ConsentManager — Google UMP (User Messaging Platform) GDPR consent flow
 *
 * The UMP SDK is part of react-native-google-mobile-ads — no extra package needed.
 *
 * Flow:
 *  1. requestInfoUpdate() — check if user's region requires consent (EU/EEA/UK)
 *  2. showIfRequired()    — shows the Google-managed consent form if needed
 *  3. getUserChoices()    — reads what the user chose
 *  4. setPersonalizedAdsAllowed() — tells AdManager to use or skip personalization
 *
 * Users outside EU/EEA/UK skip the form entirely and get personalized ads.
 *
 * Revenue impact: properly consented EU users → 30–50% higher eCPM than
 * non-personalized ads. Always worth running the consent flow.
 */

import { Platform } from "react-native";
import { setPersonalizedAdsAllowed } from "./AdManager";

export type ConsentResult =
  | "personalized"       // user consented (or not in EU)
  | "non_personalized"   // user declined
  | "unknown"            // could not determine (native module absent etc.)
  | "not_required";      // region doesn't require consent

/**
 * Run the full UMP consent flow.
 * Must be called BEFORE initializeAds() so ads load with the correct targeting.
 */
export async function runConsentFlow(): Promise<ConsentResult> {
  if (Platform.OS === "web") {
    setPersonalizedAdsAllowed(true);
    return "not_required";
  }

  try {
    const {
      AdsConsent,
      AdsConsentStatus,
      AdsConsentDebugGeography,
    } = await import("react-native-google-mobile-ads");

    // Request consent info from Google's UMP servers
    const consentInfo = await AdsConsent.requestInfoUpdate({
      // Uncomment to simulate EU geography during development:
      // debugGeography: AdsConsentDebugGeography.EEA,
      // testDeviceIdentifiers: ["YOUR_TEST_DEVICE_HASH"],
    });

    // No form available or consent already known → read existing choices
    if (
      !consentInfo.isConsentFormAvailable ||
      consentInfo.status === AdsConsentStatus.NOT_REQUIRED
    ) {
      setPersonalizedAdsAllowed(true);
      return "not_required";
    }

    if (consentInfo.status === AdsConsentStatus.OBTAINED) {
      // Consent already on file — just read and apply it
      return await _applyExistingConsent(AdsConsent);
    }

    // Status is REQUIRED — show the consent form
    if (consentInfo.status === AdsConsentStatus.REQUIRED) {
      await AdsConsent.showIfRequired();
      return await _applyExistingConsent(AdsConsent);
    }

    // Unknown status — default to non-personalized (safe)
    setPersonalizedAdsAllowed(false);
    return "unknown";
  } catch {
    // Native module absent (Expo Go) or network error
    // Default to non-personalized — safe and compliant
    setPersonalizedAdsAllowed(false);
    return "unknown";
  }
}

/**
 * Read the user's stored choices and configure AdManager accordingly.
 */
async function _applyExistingConsent(AdsConsent: {
  getUserChoices: () => Promise<{ storeAndAccessInformationOnDevice?: boolean }>;
}): Promise<ConsentResult> {
  try {
    const choices = await AdsConsent.getUserChoices();
    // storeAndAccessInformationOnDevice = true means the user consented
    const allowed = choices.storeAndAccessInformationOnDevice === true;
    setPersonalizedAdsAllowed(allowed);
    return allowed ? "personalized" : "non_personalized";
  } catch {
    setPersonalizedAdsAllowed(false);
    return "unknown";
  }
}

/**
 * Reset consent so the form shows again on next run.
 * Useful for testing or if the user wants to change their choices.
 */
export async function resetConsent(): Promise<void> {
  if (Platform.OS === "web") return;
  try {
    const { AdsConsent } = await import("react-native-google-mobile-ads");
    await AdsConsent.reset();
  } catch {
    // Ignore if native module absent
  }
}
