// Web stubs — all ad functions are no-ops on web.
// Metro picks this file automatically for the web bundle.

export const AD_UNITS = { android: {} as any, ios: {} as any };

export function setPersonalizedAdsAllowed(_allowed: boolean): void {}
export async function initializeAds(): Promise<void> {}
export async function preloadInterstitial(): Promise<void> {}
export async function onSaveAction(): Promise<void> {}
export async function preloadAppOpenAd(): Promise<void> {}
export async function showAppOpenAd(): Promise<void> {}
export function getBannerAdUnitId(): string { return ""; }
export function getBannerRequestOptions() { return {}; }
