/**
 * AdManager — production AdMob service for Status Saver
 *
 * Revenue strategy (highest to lowest CPM):
 *  1. App Open  → $2–6 eCPM — shown when user returns from background
 *  2. Interstitial → $1–5 eCPM — shown after every 3rd save
 *  3. Banner → $0.5–3 eCPM — always-on at bottom of HomeScreen
 *
 * Stability fixes:
 * - All ad code wrapped in try-catch; never throws to callers
 * - Ads preloaded in advance — zero wait time when shown
 * - Frequency caps prevent user fatigue
 * - RESULTS.NEVER_ASK_AGAIN handled in permission flow
 *
 * HOW TO GO LIVE:
 * 1. Replace androidAppId in app.json with your real AdMob App ID
 * 2. Replace all AD_UNITS below with your real Ad Unit IDs from admob.google.com
 */

import { Platform } from "react-native";

// ─── AD UNIT IDs ─────────────────────────────────────────────────────────────
// Currently using Google's official TEST IDs — safe for development.
// Replace with real IDs before publishing to Play Store.

export const AD_UNITS = {
  android: {
    banner:       "ca-app-pub-3940256099942544/6300978111",
    interstitial: "ca-app-pub-3940256099942544/1033173712",
    rewarded:     "ca-app-pub-3940256099942544/5224354917",
    appOpen:      "ca-app-pub-3940256099942544/9257395921",
  },
  ios: {
    banner:       "ca-app-pub-3940256099942544/2934735716",
    interstitial: "ca-app-pub-3940256099942544/4411468910",
    rewarded:     "ca-app-pub-3940256099942544/1712485313",
    appOpen:      "ca-app-pub-3940256099942544/5575463023",
  },
} as const;

function getUnitId(type: keyof typeof AD_UNITS.android): string {
  const platform = Platform.OS === "ios" ? "ios" : "android";
  return AD_UNITS[platform][type];
}

function adKeywords(): string[] {
  return ["whatsapp", "status", "social media", "photo", "video"];
}

// ─── SHARED CONSENT STATE ────────────────────────────────────────────────────
// Set by ConsentManager after UMP consent flow; controls personalization.
let _requestNonPersonalizedOnly = false;

export function setPersonalizedAdsAllowed(allowed: boolean): void {
  _requestNonPersonalizedOnly = !allowed;
}

// ─── INITIALIZE ──────────────────────────────────────────────────────────────

export async function initializeAds(): Promise<void> {
  if (Platform.OS === "web") return;
  try {
    const { MobileAds, MaxAdContentRating } = await import("react-native-google-mobile-ads");
    await MobileAds().initialize();
    await MobileAds().setRequestConfiguration({
      maxAdContentRating:            MaxAdContentRating.G,
      tagForChildDirectedTreatment:  false,
      tagForUnderAgeOfConsent:       false,
    });
  } catch {
    // Native module not available (Expo Go) — silent skip
  }
}

// ─── INTERSTITIAL ─────────────────────────────────────────────────────────────

type InterstitialState = {
  ad:          unknown | null;
  loading:     boolean;
  saveCounter: number;
  lastShown:   number;
};

const interstitial: InterstitialState = {
  ad: null, loading: false, saveCounter: 0, lastShown: 0,
};

const INTERSTITIAL_EVERY_N = 3;
const INTERSTITIAL_MIN_GAP = 60_000; // 60 seconds minimum between shows

export async function preloadInterstitial(): Promise<void> {
  if (Platform.OS === "web" || interstitial.loading || interstitial.ad !== null) return;
  try {
    const { InterstitialAd, AdEventType } = await import("react-native-google-mobile-ads");
    interstitial.loading = true;

    const ad = InterstitialAd.createForAdRequest(getUnitId("interstitial"), {
      requestNonPersonalizedAdsOnly: _requestNonPersonalizedOnly,
      keywords:                      adKeywords(),
    });

    ad.addAdEventListener(AdEventType.LOADED, () => {
      interstitial.ad      = ad;
      interstitial.loading = false;
    });
    ad.addAdEventListener(AdEventType.ERROR, () => {
      interstitial.ad      = null;
      interstitial.loading = false;
      // Retry after 30 seconds on error
      setTimeout(preloadInterstitial, 30_000);
    });
    ad.addAdEventListener(AdEventType.CLOSED, () => {
      interstitial.ad        = null;
      interstitial.lastShown = Date.now();
      // Preload next ad immediately after user closes
      setTimeout(preloadInterstitial, 2000);
    });

    ad.load();
  } catch {
    interstitial.loading = false;
  }
}

/**
 * Call after every save. Shows interstitial every 3 saves with a 60s cooldown.
 */
export async function onSaveAction(): Promise<void> {
  if (Platform.OS === "web") return;
  interstitial.saveCounter += 1;

  const now           = Date.now();
  const gapOk         = now - interstitial.lastShown >= INTERSTITIAL_MIN_GAP;
  const counterReady  = interstitial.saveCounter >= INTERSTITIAL_EVERY_N;
  const adReady       = interstitial.ad !== null;

  if (counterReady && gapOk && adReady) {
    interstitial.saveCounter = 0;
    try {
      const ad = interstitial.ad as { show: () => Promise<void> };
      await ad.show();
    } catch {
      interstitial.ad = null;
    }
  }
}

// ─── APP OPEN AD ──────────────────────────────────────────────────────────────

type AppOpenState = {
  ad:        unknown | null;
  loading:   boolean;
  lastShown: number;
};

const appOpen: AppOpenState = { ad: null, loading: false, lastShown: 0 };

const APP_OPEN_MIN_GAP = 4 * 60_000; // 4 minutes minimum between shows

export async function preloadAppOpenAd(): Promise<void> {
  if (Platform.OS === "web" || appOpen.loading || appOpen.ad !== null) return;
  try {
    const { AppOpenAd, AdEventType } = await import("react-native-google-mobile-ads");
    appOpen.loading = true;

    const ad = AppOpenAd.createForAdRequest(getUnitId("appOpen"), {
      requestNonPersonalizedAdsOnly: _requestNonPersonalizedOnly,
      keywords:                      adKeywords(),
    });

    ad.addAdEventListener(AdEventType.LOADED, () => {
      appOpen.ad      = ad;
      appOpen.loading = false;
    });
    ad.addAdEventListener(AdEventType.ERROR, () => {
      appOpen.ad      = null;
      appOpen.loading = false;
      setTimeout(preloadAppOpenAd, 30_000);
    });
    ad.addAdEventListener(AdEventType.CLOSED, () => {
      appOpen.ad        = null;
      appOpen.lastShown = Date.now();
      setTimeout(preloadAppOpenAd, 3000);
    });

    ad.load();
  } catch {
    appOpen.loading = false;
  }
}

/**
 * Call when app comes to foreground. Shows App Open ad ($2–6 eCPM).
 */
export async function showAppOpenAd(): Promise<void> {
  if (Platform.OS === "web" || appOpen.ad === null) return;
  if (Date.now() - appOpen.lastShown < APP_OPEN_MIN_GAP) return;
  try {
    const ad = appOpen.ad as { show: () => Promise<void> };
    await ad.show();
  } catch {
    appOpen.ad = null;
  }
}

// ─── BANNER ───────────────────────────────────────────────────────────────────

export function getBannerAdUnitId(): string {
  return getUnitId("banner");
}

export function getBannerRequestOptions() {
  return {
    requestNonPersonalizedAdsOnly: _requestNonPersonalizedOnly,
    keywords:                      adKeywords(),
  };
}
