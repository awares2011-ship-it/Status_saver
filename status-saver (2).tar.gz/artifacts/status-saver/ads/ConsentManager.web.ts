// Web stubs — GDPR consent flow is native-only.
// Metro picks this file automatically for the web bundle.

export type ConsentResult = "not_required";

export async function runConsentFlow(): Promise<ConsentResult> {
  return "not_required";
}

export async function resetConsent(): Promise<void> {}
