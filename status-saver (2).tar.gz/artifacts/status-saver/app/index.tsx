/**
 * index.tsx — root screen router
 *
 * Stability fixes:
 * 1. isMounted ref prevents state update after unmount during async init
 * 2. 8-second timeout prevents infinite spinner if permission check hangs
 * 3. Uses permissionStatus for smarter routing (never_ask_again → still show PermissionScreen)
 */

import React, { useEffect, useRef, useState } from "react";
import { ActivityIndicator, Platform, StyleSheet, View } from "react-native";

import { HomeScreen }       from "@/screens/HomeScreen";
import { PermissionScreen } from "@/screens/PermissionScreen";
import { useStatus }        from "@/context/StatusContext";
import { useColors }        from "@/hooks/useColors";

const PERMISSION_CHECK_TIMEOUT_MS = 8000;

export default function IndexScreen() {
  const colors = useColors();
  const { hasPermission, permissionChecked, checkPermission, loadStatuses } = useStatus();

  const isMounted = useRef(true);
  const [timedOut, setTimedOut] = useState(false);

  useEffect(() => {
    isMounted.current = true;
    return () => { isMounted.current = false; };
  }, []);

  useEffect(() => {
    let done = false;

    // Safety timeout: if permission check hangs > 8s, force-show PermissionScreen
    const timer = setTimeout(() => {
      if (!done && isMounted.current) setTimedOut(true);
    }, PERMISSION_CHECK_TIMEOUT_MS);

    const init = async () => {
      try {
        if (Platform.OS !== "android") {
          await loadStatuses();
        } else {
          const perm = await checkPermission();
          if (perm && isMounted.current) {
            await loadStatuses();
          }
        }
      } catch {
        // Silently ignore init errors — UI will show appropriate state
      } finally {
        done = true;
        clearTimeout(timer);
      }
    };

    init();
    return () => clearTimeout(timer);
  }, [checkPermission, loadStatuses]);

  // Still checking AND not timed out → show spinner
  if (Platform.OS === "android" && !permissionChecked && !timedOut) {
    return (
      <View style={[styles.loading, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  // No permission → show permission screen (handles denied + never_ask_again)
  if (Platform.OS === "android" && (timedOut || !hasPermission)) {
    return <PermissionScreen />;
  }

  return <HomeScreen />;
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});
