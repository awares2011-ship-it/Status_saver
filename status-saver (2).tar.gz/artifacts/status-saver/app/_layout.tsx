/**
 * Root layout — startup sequence:
 * 1. Fonts + SplashScreen
 * 2. UMP consent flow (GDPR) — must run BEFORE MobileAds.initialize()
 * 3. MobileAds.initialize() with correct personalization based on consent
 * 4. Preload App Open ad
 * 5. AppState listener → show App Open ad when user returns from background
 */

import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect, useRef } from "react";
import { AppState, AppStateStatus } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { ErrorBoundary }    from "@/components/ErrorBoundary";
import { StatusProvider }   from "@/context/StatusContext";
import { runConsentFlow }   from "@/ads/ConsentManager";
import {
  initializeAds,
  preloadAppOpenAd,
  showAppOpenAd,
} from "@/ads/AdManager";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

function RootLayoutNav() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index"   />
      <Stack.Screen name="preview" />
    </Stack>
  );
}

export default function RootLayout() {
  const appState = useRef(AppState.currentState);

  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  // Hide splash once fonts are ready (or if fonts fail)
  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync().catch(() => {});
    }
  }, [fontsLoaded, fontError]);

  // Ad startup sequence: consent → init → preload (in order)
  useEffect(() => {
    const startAds = async () => {
      try {
        // Step 1: Run GDPR consent form if required (EU/EEA/UK)
        // This sets the personalization flag before MobileAds.initialize()
        await runConsentFlow();

        // Step 2: Initialize the AdMob SDK with the correct config
        await initializeAds();

        // Step 3: Preload App Open ad so it's ready when user backgrounds the app
        preloadAppOpenAd();
      } catch {
        // Ad startup failure is non-fatal — app continues without ads
      }
    };
    startAds();
  }, []);

  // Show App Open ad when user returns to the app from background
  useEffect(() => {
    const sub = AppState.addEventListener("change", (nextState: AppStateStatus) => {
      if (
        appState.current.match(/inactive|background/) &&
        nextState === "active"
      ) {
        showAppOpenAd().catch(() => {});
      }
      appState.current = nextState;
    });
    return () => sub.remove();
  }, []);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <StatusProvider>
              <RootLayoutNav />
            </StatusProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
