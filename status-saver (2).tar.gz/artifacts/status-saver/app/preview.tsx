import { PreviewScreen } from "@/screens/PreviewScreen";

export default function PreviewPage() {
  return <PreviewScreen />;
}
