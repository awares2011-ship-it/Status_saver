/**
 * StatusContext — production-hardened state manager for Status Saver
 *
 * Stability fixes applied:
 * 1. isMounted ref guards ALL setState calls → no "update after unmount" crashes
 * 2. PermissionsAndroid uses string literals → no undefined constant crashes
 * 3. loadStatuses is fully async with per-file try-catch → no crash on bad files
 * 4. permissionStatus tracks "never_ask_again" so UI can show "Open Settings"
 * 5. Saved statuses loaded immediately on mount (not gated behind permission)
 * 6. AppState resume handler re-checks permission + reloads safely
 * 7. All file ops wrapped in try-catch with empty fallbacks
 * 8. Results cached: scan only runs when explicitly called
 */

import AsyncStorage from "@react-native-async-storage/async-storage";
import * as FileSystem from "expo-file-system";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { AppState, AppStateStatus, PermissionsAndroid, Platform } from "react-native";

// ─── PERMISSION STRINGS (never use PermissionsAndroid.PERMISSIONS.* — they  ──
// can be undefined on some RN versions / Expo Go builds)                       ─
const PERM_READ_IMAGES  = "android.permission.READ_MEDIA_IMAGES"   as const;
const PERM_READ_VIDEO   = "android.permission.READ_MEDIA_VIDEO"    as const;
const PERM_READ_STORAGE = "android.permission.READ_EXTERNAL_STORAGE" as const;

function getAndroidSdk(): number {
  if (Platform.OS !== "android") return 0;
  const v = Platform.Version;
  return typeof v === "number" ? v : parseInt(String(v), 10) || 0;
}

// ─── TYPES ───────────────────────────────────────────────────────────────────

export type MediaType = "image" | "video";
export type PermissionStatus = "granted" | "denied" | "never_ask_again" | null;

export interface StatusItem {
  id: string;
  uri: string;
  type: MediaType;
  name: string;
  modifiedTime: number;
  isSaved?: boolean;
}

interface StatusContextType {
  images: StatusItem[];
  videos: StatusItem[];
  savedStatuses: StatusItem[];
  isLoading: boolean;
  hasPermission: boolean | null;
  permissionStatus: PermissionStatus;
  permissionChecked: boolean;
  saveCount: number;
  loadStatuses: () => Promise<void>;
  saveStatus: (item: StatusItem) => Promise<boolean>;
  deleteStatus: (item: StatusItem) => Promise<boolean>;
  checkPermission: () => Promise<boolean>;
  requestPermission: () => Promise<boolean>;
  incrementSaveCount: () => void;
}

// ─── CONSTANTS ───────────────────────────────────────────────────────────────

const StatusContext = createContext<StatusContextType | null>(null);

const SAVED_KEY = "saved_statuses_v2";

const WHATSAPP_PATHS = [
  "/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/.Statuses",
  "/storage/emulated/0/WhatsApp/Media/.Statuses",
  "/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses",
  "/storage/emulated/0/WhatsApp Business/Media/.Statuses",
];

const IMAGE_EXTENSIONS = [".jpg", ".jpeg", ".png", ".gif", ".webp"];
const VIDEO_EXTENSIONS = [".mp4", ".3gp", ".mkv", ".mov"];

function isImage(name: string): boolean {
  const lower = name.toLowerCase();
  return IMAGE_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

function isVideo(name: string): boolean {
  const lower = name.toLowerCase();
  return VIDEO_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

// ─── ASYNC STORAGE HELPERS ───────────────────────────────────────────────────

async function readSavedStatuses(): Promise<StatusItem[]> {
  try {
    const raw = await AsyncStorage.getItem(SAVED_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as StatusItem[]) : [];
  } catch {
    return [];
  }
}

async function writeSavedStatuses(items: StatusItem[]): Promise<void> {
  try {
    await AsyncStorage.setItem(SAVED_KEY, JSON.stringify(items));
  } catch {
    // Storage write failure is non-fatal
  }
}

// ─── PROVIDER ────────────────────────────────────────────────────────────────

export function StatusProvider({ children }: { children: React.ReactNode }) {
  const [images, setImages]               = useState<StatusItem[]>([]);
  const [videos, setVideos]               = useState<StatusItem[]>([]);
  const [savedStatuses, setSavedStatuses] = useState<StatusItem[]>([]);
  const [isLoading, setIsLoading]         = useState(false);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [permissionStatus, setPermissionStatus] = useState<PermissionStatus>(null);
  const [permissionChecked, setPermissionChecked] = useState(false);
  const [saveCount, setSaveCount]         = useState(0);

  // isMounted guard — prevents all setState calls after component unmounts
  const isMounted = useRef(true);
  const appState  = useRef(AppState.currentState);

  useEffect(() => {
    isMounted.current = true;
    return () => { isMounted.current = false; };
  }, []);

  // ─── SAVE DIR ──────────────────────────────────────────────────────────────

  const getSaveDir = useCallback((): string => {
    const base = FileSystem.documentDirectory ?? "";
    return `${base}SavedStatuses/`;
  }, []);

  const ensureSaveDir = useCallback(async (): Promise<void> => {
    const dir = getSaveDir();
    try {
      const info = await FileSystem.getInfoAsync(dir);
      if (!info.exists) {
        await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
      }
    } catch {
      // Non-fatal: save will fail below with a clear false return
    }
  }, [getSaveDir]);

  // ─── PERMISSION CHECK ─────────────────────────────────────────────────────

  const checkPermission = useCallback(async (): Promise<boolean> => {
    if (Platform.OS !== "android") {
      if (isMounted.current) {
        setHasPermission(true);
        setPermissionStatus("granted");
        setPermissionChecked(true);
      }
      return true;
    }
    try {
      const sdk = getAndroidSdk();
      let granted = false;

      if (sdk >= 33) {
        const imgOk = await PermissionsAndroid.check(PERM_READ_IMAGES as any);
        const vidOk = await PermissionsAndroid.check(PERM_READ_VIDEO as any);
        granted = imgOk && vidOk;
      } else {
        granted = await PermissionsAndroid.check(PERM_READ_STORAGE as any);
      }

      if (isMounted.current) {
        setHasPermission(granted);
        setPermissionStatus(granted ? "granted" : "denied");
        setPermissionChecked(true);
      }
      return granted;
    } catch {
      if (isMounted.current) {
        setHasPermission(false);
        setPermissionStatus("denied");
        setPermissionChecked(true);
      }
      return false;
    }
  }, []);

  // ─── PERMISSION REQUEST ───────────────────────────────────────────────────

  const requestPermission = useCallback(async (): Promise<boolean> => {
    if (Platform.OS !== "android") {
      if (isMounted.current) {
        setHasPermission(true);
        setPermissionStatus("granted");
        setPermissionChecked(true);
      }
      return true;
    }
    try {
      const sdk = getAndroidSdk();
      let granted = false;
      let neverAsk = false;

      if (sdk >= 33) {
        const imgResult = await PermissionsAndroid.request(
          PERM_READ_IMAGES as any,
          {
            title: "Media Permission",
            message: "Allow Status Saver to view WhatsApp photos and videos",
            buttonPositive: "Allow",
            buttonNegative: "Deny",
          }
        );
        const vidResult = await PermissionsAndroid.request(
          PERM_READ_VIDEO as any,
          {
            title: "Video Permission",
            message: "Allow Status Saver to view WhatsApp video statuses",
            buttonPositive: "Allow",
            buttonNegative: "Deny",
          }
        );
        granted =
          imgResult === PermissionsAndroid.RESULTS.GRANTED &&
          vidResult === PermissionsAndroid.RESULTS.GRANTED;
        neverAsk =
          imgResult === PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN ||
          vidResult === PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN;
      } else {
        const result = await PermissionsAndroid.request(
          PERM_READ_STORAGE as any,
          {
            title: "Storage Permission",
            message: "Allow Status Saver to view WhatsApp statuses",
            buttonPositive: "Allow",
            buttonNegative: "Deny",
          }
        );
        granted = result === PermissionsAndroid.RESULTS.GRANTED;
        neverAsk = result === PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN;
      }

      const status: PermissionStatus = granted
        ? "granted"
        : neverAsk
        ? "never_ask_again"
        : "denied";

      if (isMounted.current) {
        setHasPermission(granted);
        setPermissionStatus(status);
        setPermissionChecked(true);
      }
      return granted;
    } catch {
      if (isMounted.current) {
        setHasPermission(false);
        setPermissionStatus("denied");
        setPermissionChecked(true);
      }
      return false;
    }
  }, []);

  // ─── LOAD STATUSES ────────────────────────────────────────────────────────

  const loadStatuses = useCallback(async (): Promise<void> => {
    if (Platform.OS !== "android") {
      if (isMounted.current) {
        setIsLoading(false);
        setImages([]);
        setVideos([]);
      }
      return;
    }

    if (isMounted.current) setIsLoading(true);

    try {
      // Load saved list first (always available regardless of permission)
      const savedItems = await readSavedStatuses();
      const savedIds   = new Set(savedItems.map((s) => s.id));

      const allImages: StatusItem[] = [];
      const allVideos: StatusItem[] = [];

      for (const dirPath of WHATSAPP_PATHS) {
        // Per-directory try-catch: one missing folder never crashes the scan
        try {
          const dirUri  = `file://${dirPath}`;
          const dirInfo = await FileSystem.getInfoAsync(dirUri);

          // Skip if directory doesn't exist or isn't a directory
          if (!dirInfo.exists) continue;

          let files: string[] = [];
          try {
            files = await FileSystem.readDirectoryAsync(dirUri);
          } catch {
            // readDirectory can throw if permission denied at OS level
            continue;
          }

          for (const file of files) {
            // Per-file try-catch: one bad file never crashes the scan
            try {
              const lower = file.toLowerCase();
              // Skip non-media and .nomedia files
              if (!isImage(lower) && !isVideo(lower)) continue;
              if (lower === ".nomedia") continue;

              const uri = `${dirUri}/${file}`;
              let modifiedTime = Date.now();

              try {
                const info = await FileSystem.getInfoAsync(uri, { md5: false });
                if (info.exists && "modificationTime" in info) {
                  const mt = (info as { modificationTime?: number }).modificationTime;
                  modifiedTime = typeof mt === "number" ? mt * 1000 : Date.now();
                }
              } catch {
                // Fallback to current time — non-fatal
              }

              const id = `${dirPath}/${file}`;
              const item: StatusItem = {
                id,
                uri,
                type: isImage(lower) ? "image" : "video",
                name: file,
                modifiedTime,
                isSaved: savedIds.has(id),
              };

              if (isImage(lower)) allImages.push(item);
              else allVideos.push(item);
            } catch {
              // Skip this file
            }
          }
        } catch {
          // Skip this directory entirely
        }
      }

      // Sort newest-first
      allImages.sort((a, b) => b.modifiedTime - a.modifiedTime);
      allVideos.sort((a, b) => b.modifiedTime - a.modifiedTime);

      // Guard all setState calls
      if (isMounted.current) {
        setImages(allImages);
        setVideos(allVideos);
        setSavedStatuses(savedItems);
      }
    } catch {
      // Outer fallback — should never reach here but prevents any crash
      if (isMounted.current) {
        setImages([]);
        setVideos([]);
      }
    } finally {
      if (isMounted.current) {
        setIsLoading(false);
      }
    }
  }, []);

  // ─── SAVE STATUS ──────────────────────────────────────────────────────────

  const saveStatus = useCallback(
    async (item: StatusItem): Promise<boolean> => {
      if (!item?.uri || !item?.name) return false;
      try {
        await ensureSaveDir();
        const saveDir  = getSaveDir();
        const destPath = `${saveDir}${item.name}`;

        // Copy only if not already present
        try {
          const existing = await FileSystem.getInfoAsync(destPath);
          if (!existing.exists) {
            await FileSystem.copyAsync({ from: item.uri, to: destPath });
          }
        } catch {
          // copyAsync can fail if source is no longer accessible
          return false;
        }

        const savedItems = await readSavedStatuses();
        const alreadySaved = savedItems.some((s) => s.id === item.id);

        if (!alreadySaved) {
          const updatedItem: StatusItem = { ...item, isSaved: true, uri: destPath };
          const updated = [updatedItem, ...savedItems];
          await writeSavedStatuses(updated);

          if (isMounted.current) {
            setSavedStatuses(updated);
            setImages((prev) =>
              prev.map((i) => (i.id === item.id ? { ...i, isSaved: true } : i))
            );
            setVideos((prev) =>
              prev.map((i) => (i.id === item.id ? { ...i, isSaved: true } : i))
            );
          }
        }

        return true;
      } catch {
        return false;
      }
    },
    [ensureSaveDir, getSaveDir]
  );

  // ─── DELETE STATUS ────────────────────────────────────────────────────────

  const deleteStatus = useCallback(async (item: StatusItem): Promise<boolean> => {
    if (!item?.id) return false;
    try {
      const savedItems = await readSavedStatuses();
      const updated    = savedItems.filter((s) => s.id !== item.id);
      await writeSavedStatuses(updated);

      if (isMounted.current) {
        setSavedStatuses(updated);
      }

      // Delete the physical file (best-effort, non-fatal if it fails)
      try {
        const info = await FileSystem.getInfoAsync(item.uri);
        if (info.exists) {
          await FileSystem.deleteAsync(item.uri, { idempotent: true });
        }
      } catch {
        // File already gone — fine
      }

      return true;
    } catch {
      return false;
    }
  }, []);

  // ─── MISC ─────────────────────────────────────────────────────────────────

  const incrementSaveCount = useCallback(() => {
    if (isMounted.current) setSaveCount((c) => c + 1);
  }, []);

  // ─── BOOT: load saved list & setup AppState listener ──────────────────────

  useEffect(() => {
    // Always load the saved-statuses list immediately (no permission needed)
    readSavedStatuses()
      .then((items) => {
        if (isMounted.current) setSavedStatuses(items);
      })
      .catch(() => {});

    // Reload when app comes back to foreground
    const sub = AppState.addEventListener("change", (nextState: AppStateStatus) => {
      if (
        appState.current.match(/inactive|background/) &&
        nextState === "active"
      ) {
        // Re-check permission (user may have changed it in Settings)
        checkPermission()
          .then((perm) => {
            if (perm && isMounted.current) loadStatuses();
          })
          .catch(() => {});
      }
      appState.current = nextState;
    });

    return () => sub.remove();
  }, [checkPermission, loadStatuses]);

  // ─── CONTEXT VALUE ────────────────────────────────────────────────────────

  return (
    <StatusContext.Provider
      value={{
        images,
        videos,
        savedStatuses,
        isLoading,
        hasPermission,
        permissionStatus,
        permissionChecked,
        saveCount,
        loadStatuses,
        saveStatus,
        deleteStatus,
        checkPermission,
        requestPermission,
        incrementSaveCount,
      }}
    >
      {children}
    </StatusContext.Provider>
  );
}

export function useStatus(): StatusContextType {
  const ctx = useContext(StatusContext);
  if (!ctx) throw new Error("useStatus must be used within <StatusProvider>");
  return ctx;
}
