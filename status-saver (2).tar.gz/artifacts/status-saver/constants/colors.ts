const colors = {
  light: {
    text: "#1a1a1a",
    tint: "#00a884",

    background: "#f0f2f5",
    foreground: "#1a1a1a",

    card: "#ffffff",
    cardForeground: "#1a1a1a",

    primary: "#00a884",
    primaryForeground: "#ffffff",
    primaryDark: "#008f71",

    secondary: "#e9edef",
    secondaryForeground: "#3b4a54",

    muted: "#e9edef",
    mutedForeground: "#8696a0",

    accent: "#25d366",
    accentForeground: "#ffffff",

    destructive: "#ef4444",
    destructiveForeground: "#ffffff",

    border: "#d1d7db",
    input: "#d1d7db",

    surface: "#ffffff",
    surfaceElevated: "#f7f8fa",

    tabBar: "#ffffff",
    tabBarBorder: "#e9edef",
    header: "#00a884",
    headerText: "#ffffff",

    overlay: "rgba(0,0,0,0.6)",
    shimmer: "#e9edef",
    shimmerHighlight: "#f5f5f5",
  },

  dark: {
    text: "#e9edef",
    tint: "#00a884",

    background: "#111b21",
    foreground: "#e9edef",

    card: "#1f2c34",
    cardForeground: "#e9edef",

    primary: "#00a884",
    primaryForeground: "#ffffff",
    primaryDark: "#008f71",

    secondary: "#2a3942",
    secondaryForeground: "#aebac1",

    muted: "#2a3942",
    mutedForeground: "#8696a0",

    accent: "#25d366",
    accentForeground: "#ffffff",

    destructive: "#ef4444",
    destructiveForeground: "#ffffff",

    border: "#2a3942",
    input: "#2a3942",

    surface: "#1f2c34",
    surfaceElevated: "#2a3942",

    tabBar: "#1f2c34",
    tabBarBorder: "#2a3942",
    header: "#1f2c34",
    headerText: "#e9edef",

    overlay: "rgba(0,0,0,0.8)",
    shimmer: "#2a3942",
    shimmerHighlight: "#3b4a54",
  },

  radius: 12,
};

export default colors;
