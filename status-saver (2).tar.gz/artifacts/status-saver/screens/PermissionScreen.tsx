/**
 * PermissionScreen — stability fixes:
 * 1. Reads permissionStatus from context to detect "never_ask_again"
 * 2. When "never_ask_again", shows Settings as the primary action (no dialog will appear)
 * 3. Always shows feedback — never a silent no-op tap
 * 4. isMounted ref prevents setState after unmount
 */

import { Feather } from "@expo/vector-icons";
import * as Linking from "expo-linking";
import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useStatus } from "@/context/StatusContext";
import { useColors } from "@/hooks/useColors";

export function PermissionScreen() {
  const colors = useColors();
  const insets  = useSafeAreaInsets();
  const { requestPermission, loadStatuses, permissionStatus } = useStatus();
  const [requesting, setRequesting] = useState(false);
  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    return () => { isMounted.current = false; };
  }, []);

  // If user previously chose "Don't ask again", the OS won't show a dialog.
  // Skip straight to Settings as the primary action.
  const isNeverAsk = permissionStatus === "never_ask_again";

  const openSettings = () => {
    Linking.openSettings().catch(() => {
      Alert.alert(
        "Open Settings Manually",
        'Go to Settings → Apps → Status Saver → Permissions\nand enable "Photos and videos" or "Storage".'
      );
    });
  };

  const handleGrantPermission = async () => {
    if (requesting) return;

    // If we know the dialog won't appear, go straight to Settings
    if (isNeverAsk) {
      openSettings();
      return;
    }

    if (isMounted.current) setRequesting(true);
    try {
      const granted = await requestPermission();
      if (!isMounted.current) return;

      if (granted) {
        await loadStatuses();
        // hasPermission now true → index.tsx renders HomeScreen automatically
      } else {
        // Could be "denied" or "never_ask_again" now — show Settings path
        Alert.alert(
          "Permission Required",
          "Storage permission was denied.\n\nPlease open Settings and grant the permission manually.",
          [
            { text: "Later", style: "cancel" },
            { text: "Open Settings", onPress: openSettings },
          ]
        );
      }
    } catch {
      if (!isMounted.current) return;
      Alert.alert(
        "Permission Error",
        "Could not request permission. Please open Settings and grant it manually.",
        [
          { text: "Later", style: "cancel" },
          { text: "Open Settings", onPress: openSettings },
        ]
      );
    } finally {
      if (isMounted.current) setRequesting(false);
    }
  };

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: colors.background,
          paddingTop:    insets.top + (Platform.OS === "web" ? 67 : 0),
          paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 0),
        },
      ]}
    >
      <View style={styles.content}>
        <View style={[styles.iconCircle, { backgroundColor: colors.primary + "20" }]}>
          <Feather name="folder" size={48} color={colors.primary} />
        </View>

        <Text style={[styles.title, { color: colors.foreground }]}>
          {isNeverAsk ? "Enable Permission in Settings" : "Storage Permission Required"}
        </Text>

        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          {isNeverAsk
            ? 'You previously denied this permission. Please tap "Open Settings" below and enable Photos & Videos access for Status Saver.'
            : "Status Saver needs access to your device storage to find and display WhatsApp statuses shared by your contacts."}
        </Text>

        <View style={[styles.infoCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {[
            { icon: "image",    text: "View photos & videos from WhatsApp statuses" },
            { icon: "download", text: "Save statuses to your device" },
            { icon: "share-2",  text: "Share and repost statuses with friends"      },
            { icon: "shield",   text: "We never upload or share your files"         },
          ].map((item) => (
            <View key={item.text} style={styles.infoRow}>
              <Feather name={item.icon as any} size={18} color={colors.primary} />
              <Text style={[styles.infoText, { color: colors.foreground }]}>
                {item.text}
              </Text>
            </View>
          ))}
        </View>

        {/* Primary action */}
        <Pressable
          style={({ pressed }) => [
            styles.button,
            {
              backgroundColor: requesting ? colors.primaryDark : colors.primary,
              opacity: pressed ? 0.88 : 1,
            },
          ]}
          onPress={isNeverAsk ? openSettings : handleGrantPermission}
          disabled={requesting}
        >
          {requesting ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <>
              <Feather
                name={isNeverAsk ? "settings" : "unlock"}
                size={18}
                color="#fff"
              />
              <Text style={styles.buttonText}>
                {isNeverAsk ? "Open Settings" : "Grant Permission"}
              </Text>
            </>
          )}
        </Pressable>

        {/* Secondary action — always show Open Settings as a fallback */}
        {!isNeverAsk && (
          <Pressable
            style={({ pressed }) => [
              styles.secondaryButton,
              { backgroundColor: colors.secondary, opacity: pressed ? 0.85 : 1 },
            ]}
            onPress={openSettings}
          >
            <Feather name="settings" size={16} color={colors.secondaryForeground} />
            <Text style={[styles.secondaryButtonText, { color: colors.secondaryForeground }]}>
              Open Settings Instead
            </Text>
          </Pressable>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 28,
    gap: 20,
  },
  iconCircle: {
    width: 96, height: 96, borderRadius: 48,
    alignItems: "center", justifyContent: "center",
    marginBottom: 8,
  },
  title:    { fontSize: 24, fontWeight: "700", textAlign: "center" },
  subtitle: { fontSize: 15, textAlign: "center", lineHeight: 22 },
  infoCard: {
    width: "100%",
    borderRadius: 16, padding: 20, gap: 14, borderWidth: 1,
  },
  infoRow:  { flexDirection: "row", alignItems: "flex-start", gap: 12 },
  infoText: { fontSize: 14, flex: 1, lineHeight: 20 },
  button: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    width: "100%", height: 52, borderRadius: 26, gap: 10,
  },
  buttonText: { color: "#fff", fontSize: 16, fontWeight: "700" },
  secondaryButton: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    width: "100%", height: 48, borderRadius: 24, gap: 8,
  },
  secondaryButtonText: { fontSize: 15, fontWeight: "600" },
});
