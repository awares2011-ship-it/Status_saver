/**
 * PreviewScreen — stability fixes:
 * 1. isMounted ref guards all async setState calls
 * 2. Null-safe params.id handling
 * 3. All action handlers check isMounted before updating state
 * 4. Share/repost uses correct MIME types
 * 5. Saving spinners always reset even on error
 */

import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { Image } from "expo-image";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as Sharing from "expo-sharing";
import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Animated,
  Dimensions,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { onSaveAction } from "@/ads/AdManager";
import { useStatus } from "@/context/StatusContext";
import { useColors } from "@/hooks/useColors";

const { width, height } = Dimensions.get("window");

export function PreviewScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router  = useRouter();
  const params  = useLocalSearchParams<{ id?: string }>();

  const {
    images,
    videos,
    savedStatuses,
    saveStatus,
    deleteStatus,
    incrementSaveCount,
  } = useStatus();

  const [saving,    setSaving]    = useState(false);
  const [sharing,   setSharing]   = useState(false);
  const [reposting, setReposting] = useState(false);
  const [snackbar,  setSnackbar]  = useState<string | null>(null);

  const snackbarAnim = useRef(new Animated.Value(0)).current;
  const isMounted    = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    return () => { isMounted.current = false; };
  }, []);

  // ─── Find item ─────────────────────────────────────────────────────────────
  const itemId = params.id ?? null;

  const allItems = [
    ...images,
    ...videos,
    ...savedStatuses.filter(
      (s) =>
        !images.some((i) => i.id === s.id) &&
        !videos.some((v) => v.id === s.id)
    ),
  ];
  const item = itemId ? allItems.find((i) => i.id === itemId) ?? null : null;

  // ─── Snackbar ─────────────────────────────────────────────────────────────

  const showSnackbar = (msg: string) => {
    if (!isMounted.current) return;
    setSnackbar(msg);
    Animated.sequence([
      Animated.timing(snackbarAnim, { toValue: 1, duration: 200, useNativeDriver: true }),
      Animated.delay(2200),
      Animated.timing(snackbarAnim, { toValue: 0, duration: 200, useNativeDriver: true }),
    ]).start(() => {
      if (isMounted.current) setSnackbar(null);
    });
  };

  // ─── Save ─────────────────────────────────────────────────────────────────

  const handleSave = async () => {
    if (!item || saving) return;
    if (isMounted.current) setSaving(true);
    try {
      const success = await saveStatus(item);
      if (!isMounted.current) return;
      if (success) {
        incrementSaveCount();
        if (Platform.OS !== "web") {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
        }
        showSnackbar("Status saved to your device!");
        onSaveAction(); // trigger interstitial every 3 saves
      } else {
        showSnackbar("Could not save. Please try again.");
      }
    } catch {
      if (isMounted.current) showSnackbar("An error occurred while saving.");
    } finally {
      if (isMounted.current) setSaving(false);
    }
  };

  // ─── Share ────────────────────────────────────────────────────────────────

  const handleShare = async () => {
    if (!item || sharing) return;
    if (isMounted.current) setSharing(true);
    try {
      if (Platform.OS !== "web") {
        const available = await Sharing.isAvailableAsync();
        if (available) {
          await Sharing.shareAsync(item.uri, {
            mimeType: item.type === "video" ? "video/mp4" : "image/jpeg",
            dialogTitle: "Share Status",
          });
        }
      }
    } catch {
      if (isMounted.current) showSnackbar("Could not share this file.");
    } finally {
      if (isMounted.current) setSharing(false);
    }
  };

  // ─── Repost ───────────────────────────────────────────────────────────────

  const handleRepost = async () => {
    if (!item || reposting) return;
    if (isMounted.current) setReposting(true);
    try {
      if (Platform.OS === "web") {
        showSnackbar("Repost is available on Android & iOS only.");
        return;
      }
      const available = await Sharing.isAvailableAsync();
      if (!available) {
        showSnackbar("Sharing is not available on this device.");
        return;
      }
      await Sharing.shareAsync(item.uri, {
        mimeType:    item.type === "video" ? "video/mp4" : "image/jpeg",
        dialogTitle: "Repost to WhatsApp Status",
        UTI:         item.type === "video" ? "public.movie" : "public.image",
      });
    } catch {
      if (isMounted.current) showSnackbar("Could not repost this status.");
    } finally {
      if (isMounted.current) setReposting(false);
    }
  };

  // ─── Delete ───────────────────────────────────────────────────────────────

  const handleDelete = () => {
    if (!item) return;
    Alert.alert(
      "Delete Status",
      "Remove this saved status from your device?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              await deleteStatus(item);
              if (isMounted.current) router.back();
            } catch {
              if (isMounted.current) showSnackbar("Could not delete this status.");
            }
          },
        },
      ],
      { cancelable: true }
    );
  };

  // ─── Guard: no item found ─────────────────────────────────────────────────

  if (!item) {
    return (
      <View style={[styles.container, { backgroundColor: "#000" }]}>
        <Pressable
          style={[styles.backFallback, { top: insets.top + 8 }]}
          onPress={() => router.back()}
        >
          <Feather name="arrow-left" size={24} color="#fff" />
        </Pressable>
        <Text style={styles.notFound}>Status not found</Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: "#000" }]}>

      {/* Media area */}
      <View style={styles.mediaContainer}>
        {item.type === "image" ? (
          <ScrollView
            maximumZoomScale={4}
            minimumZoomScale={1}
            centerContent
            style={styles.scrollView}
            contentContainerStyle={styles.imageContainer}
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
          >
            <Image
              source={{ uri: item.uri }}
              style={styles.image}
              contentFit="contain"
              onError={() => {
                if (isMounted.current) showSnackbar("Could not load image.");
              }}
            />
          </ScrollView>
        ) : (
          <View style={styles.videoPlaceholder}>
            <View style={styles.videoIconWrap}>
              <Feather name="play" size={36} color="rgba(255,255,255,0.9)" />
            </View>
            <Text style={styles.videoNote}>Video preview — save to play in gallery</Text>
          </View>
        )}
      </View>

      {/* Top bar */}
      <View style={[styles.topBar, { paddingTop: insets.top + (Platform.OS === "web" ? 67 : 8) }]}>
        <Pressable
          style={({ pressed }) => [styles.iconBtn, { opacity: pressed ? 0.7 : 1 }]}
          onPress={() => router.back()}
          hitSlop={8}
        >
          <Feather name="arrow-left" size={24} color="#fff" />
        </Pressable>
        <Text style={styles.topBarTitle} numberOfLines={1}>
          {item.type === "image" ? "Photo" : "Video"}
        </Text>
        {item.isSaved ? (
          <Pressable
            style={({ pressed }) => [styles.iconBtn, { opacity: pressed ? 0.7 : 1 }]}
            onPress={handleDelete}
            hitSlop={8}
          >
            <Feather name="trash-2" size={22} color="#ff5555" />
          </Pressable>
        ) : (
          <View style={styles.iconBtn} />
        )}
      </View>

      {/* Bottom action bar */}
      <View style={[styles.bottomBar, { paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 16) }]}>

        {/* Save */}
        <Pressable
          style={({ pressed }) => [
            styles.actionBtn,
            {
              backgroundColor: item.isSaved ? "rgba(255,255,255,0.12)" : colors.primary,
              opacity: pressed || saving ? 0.8 : 1,
            },
          ]}
          onPress={handleSave}
          disabled={saving || !!item.isSaved}
        >
          {saving ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <>
              <Feather name={item.isSaved ? "check-circle" : "download"} size={18} color="#fff" />
              <Text style={styles.actionBtnText}>{item.isSaved ? "Saved" : "Save"}</Text>
            </>
          )}
        </Pressable>

        {/* Share */}
        <Pressable
          style={({ pressed }) => [
            styles.actionBtn,
            { backgroundColor: "rgba(255,255,255,0.12)", opacity: pressed || sharing ? 0.8 : 1 },
          ]}
          onPress={handleShare}
          disabled={sharing}
        >
          {sharing ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <>
              <Feather name="share-2" size={18} color="#fff" />
              <Text style={styles.actionBtnText}>Share</Text>
            </>
          )}
        </Pressable>

        {/* Repost */}
        <Pressable
          style={({ pressed }) => [
            styles.actionBtn,
            { backgroundColor: "#25d366", opacity: pressed || reposting ? 0.8 : 1 },
          ]}
          onPress={handleRepost}
          disabled={reposting}
        >
          {reposting ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <>
              <Feather name="refresh-cw" size={18} color="#fff" />
              <Text style={styles.actionBtnText}>Repost</Text>
            </>
          )}
        </Pressable>
      </View>

      {/* Snackbar */}
      {snackbar && (
        <Animated.View
          style={[
            styles.snackbar,
            {
              bottom: insets.bottom + 110,
              opacity: snackbarAnim,
              backgroundColor: colors.card,
            },
          ]}
        >
          <Text style={[styles.snackbarText, { color: colors.foreground }]}>
            {snackbar}
          </Text>
        </Animated.View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container:       { flex: 1 },
  mediaContainer:  { flex: 1 },
  scrollView:      { flex: 1 },
  imageContainer:  { flex: 1, alignItems: "center", justifyContent: "center" },
  image:           { width, height },
  videoPlaceholder:{ flex: 1, alignItems: "center", justifyContent: "center", gap: 14 },
  videoIconWrap:   {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: "rgba(255,255,255,0.15)",
    alignItems: "center", justifyContent: "center",
  },
  videoNote: { color: "rgba(255,255,255,0.55)", fontSize: 13 },
  topBar: {
    position: "absolute", top: 0, left: 0, right: 0,
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 12, paddingBottom: 14,
    backgroundColor: "rgba(0,0,0,0.55)",
  },
  topBarTitle: {
    color: "#fff", fontSize: 16, fontWeight: "600",
    flex: 1, textAlign: "center",
  },
  iconBtn: { width: 40, height: 40, alignItems: "center", justifyContent: "center" },
  backFallback: {
    position: "absolute", left: 12,
    width: 40, height: 40, alignItems: "center", justifyContent: "center",
    zIndex: 10,
  },
  bottomBar: {
    position: "absolute", bottom: 0, left: 0, right: 0,
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 10, paddingTop: 16, paddingHorizontal: 16,
    backgroundColor: "rgba(0,0,0,0.65)",
  },
  actionBtn: {
    flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center",
    height: 46, borderRadius: 23, gap: 6,
  },
  actionBtnText: { color: "#fff", fontSize: 14, fontWeight: "600" },
  snackbar: {
    position: "absolute", left: 24, right: 24,
    borderRadius: 12, paddingVertical: 12, paddingHorizontal: 20,
    shadowColor: "#000", shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2, shadowRadius: 8, elevation: 5,
  },
  snackbarText: { fontSize: 14, fontWeight: "500", textAlign: "center" },
  notFound: { color: "#fff", textAlign: "center", marginTop: 100 },
});
