import { Feather } from "@expo/vector-icons";
import * as Linking from "expo-linking";
import { useRouter } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { AdBanner } from "@/components/AdBanner";
import { StatusGrid } from "@/components/StatusGrid";
import { StatusItem, useStatus } from "@/context/StatusContext";
import { useColors } from "@/hooks/useColors";

type TabId = "images" | "videos" | "saved";

const TABS: { id: TabId; label: string; icon: string }[] = [
  { id: "images", label: "Images", icon: "image" },
  { id: "videos", label: "Videos", icon: "video" },
  { id: "saved", label: "Saved", icon: "bookmark" },
];

export function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<TabId>("images");
  const indicatorAnim = useRef(new Animated.Value(0)).current;
  const { images, videos, savedStatuses, isLoading, loadStatuses } = useStatus();

  const TAB_WIDTH = 1 / 3;

  useEffect(() => {
    const idx = TABS.findIndex((t) => t.id === activeTab);
    Animated.spring(indicatorAnim, {
      toValue: idx,
      useNativeDriver: true,
      tension: 80,
      friction: 12,
    }).start();
  }, [activeTab, indicatorAnim]);

  const handlePress = (item: StatusItem) => {
    router.push(`/preview?id=${encodeURIComponent(item.id)}`);
  };

  const openWhatsApp = async () => {
    try {
      await Linking.openURL("whatsapp://");
    } catch {
      try {
        await Linking.openURL("market://details?id=com.whatsapp");
      } catch {
        await Linking.openURL(
          "https://play.google.com/store/apps/details?id=com.whatsapp"
        );
      }
    }
  };

  const currentItems =
    activeTab === "images"
      ? images
      : activeTab === "videos"
      ? videos
      : savedStatuses;

  const emptyMessages: Record<TabId, string> = {
    images: "No image statuses found",
    videos: "No video statuses found",
    saved: "No saved statuses yet",
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.header,
          {
            backgroundColor: colors.header,
            paddingTop: insets.top + (Platform.OS === "web" ? 67 : 8),
          },
        ]}
      >
        <Text style={[styles.headerTitle, { color: colors.headerText }]}>
          Status Saver
        </Text>
        <Pressable
          style={({ pressed }) => [
            styles.waButton,
            { backgroundColor: "rgba(255,255,255,0.18)", opacity: pressed ? 0.8 : 1 },
          ]}
          onPress={openWhatsApp}
        >
          <Feather name="message-circle" size={18} color={colors.headerText} />
          <Text style={[styles.waButtonText, { color: colors.headerText }]}>
            Open WhatsApp
          </Text>
        </Pressable>
      </View>

      <View
        style={[
          styles.tabBar,
          { backgroundColor: colors.header, borderBottomColor: colors.primaryDark },
        ]}
      >
        {TABS.map((tab, idx) => (
          <Pressable
            key={tab.id}
            style={styles.tab}
            onPress={() => setActiveTab(tab.id)}
          >
            <Text
              style={[
                styles.tabLabel,
                {
                  color:
                    activeTab === tab.id
                      ? colors.headerText
                      : "rgba(255,255,255,0.6)",
                  fontWeight: activeTab === tab.id ? "700" : "400",
                },
              ]}
            >
              {tab.label}
              {tab.id === "saved" && savedStatuses.length > 0
                ? ` (${savedStatuses.length})`
                : ""}
            </Text>
          </Pressable>
        ))}

        <Animated.View
          style={[
            styles.indicator,
            {
              backgroundColor: colors.headerText,
              width: `${TAB_WIDTH * 100}%`,
              transform: [
                {
                  translateX: indicatorAnim.interpolate({
                    inputRange: [0, 1, 2],
                    outputRange: [0, 120, 240],
                  }),
                },
              ],
            },
          ]}
        />
      </View>

      <View style={styles.content}>
        <StatusGrid
          items={currentItems}
          isLoading={isLoading}
          onRefresh={loadStatuses}
          onPress={handlePress}
          emptyMessage={emptyMessages[activeTab]}
        />
      </View>

      <AdBanner />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "700",
  },
  waButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 20,
  },
  waButtonText: {
    fontSize: 13,
    fontWeight: "600",
  },
  tabBar: {
    flexDirection: "row",
    position: "relative",
    borderBottomWidth: 2,
  },
  tab: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 12,
  },
  tabLabel: {
    fontSize: 13,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  indicator: {
    position: "absolute",
    bottom: -2,
    height: 2,
    left: 0,
  },
  content: {
    flex: 1,
  },
});
