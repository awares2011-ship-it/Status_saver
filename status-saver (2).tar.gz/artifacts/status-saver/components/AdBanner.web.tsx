// Web stub — AdMob is native-only and never loads on web.
// Metro picks this file automatically for the web bundle.
export function AdBanner() {
  return null;
}
