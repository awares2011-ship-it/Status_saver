/**
 * AdBanner — live AdMob banner (ANCHORED_ADAPTIVE_BANNER for best fill rate).
 *
 * - Works in production APK builds automatically
 * - Shows a placeholder in Expo Go (native module absent)
 * - Uses requestOptions from AdManager (respects GDPR consent state)
 * - onAdFailedToLoad hides the banner gracefully instead of crashing
 */

import React, { useState } from "react";
import { Platform, StyleSheet, Text, View } from "react-native";

import { getBannerAdUnitId, getBannerRequestOptions } from "@/ads/AdManager";
import { useColors } from "@/hooks/useColors";

export function AdBanner() {
  const colors = useColors();
  const [visible, setVisible] = useState(true);

  if (Platform.OS === "web") return null;

  try {
    // Dynamic require so bundle doesn't crash when native module is absent
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { BannerAd, BannerAdSize } = require("react-native-google-mobile-ads");

    if (!visible) return null;

    return (
      <View style={styles.container}>
        <BannerAd
          unitId={getBannerAdUnitId()}
          size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER}
          requestOptions={getBannerRequestOptions()}
          onAdLoaded={() => setVisible(true)}
          onAdFailedToLoad={() => setVisible(false)}
        />
      </View>
    );
  } catch {
    // Native module not available — show placeholder in development
    return (
      <View style={[styles.placeholder, { backgroundColor: colors.surfaceElevated, borderTopColor: colors.border }]}>
        <Text style={[styles.placeholderText, { color: colors.mutedForeground }]}>
          Ad Banner · enabled in production build
        </Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container:       { alignItems: "center", width: "100%" },
  placeholder:     { height: 52, alignItems: "center", justifyContent: "center", borderTopWidth: StyleSheet.hairlineWidth },
  placeholderText: { fontSize: 11, letterSpacing: 0.3 },
});
