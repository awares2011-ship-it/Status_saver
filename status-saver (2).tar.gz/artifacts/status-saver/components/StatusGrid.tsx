/**
 * StatusGrid — stability & performance fixes:
 * 1. Null-safe items guard (items || []) prevents crash on undefined
 * 2. FlatList perf props: initialNumToRender, maxToRenderPerBatch, windowSize
 * 3. getItemLayout for fixed-size grid (avoids layout recalculation)
 * 4. keyboardShouldPersistTaps for scroll reliability
 * 5. Image onError handler — broken images don't crash the grid
 */

import { Feather } from "@expo/vector-icons";
import { Image } from "expo-image";
import React, { useCallback, useMemo } from "react";
import {
  Animated,
  Dimensions,
  FlatList,
  Platform,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { StatusItem } from "@/context/StatusContext";
import { useColors } from "@/hooks/useColors";

interface StatusGridProps {
  items: StatusItem[];
  isLoading: boolean;
  onRefresh: () => void;
  onPress: (item: StatusItem, index: number) => void;
  emptyMessage?: string;
}

const { width } = Dimensions.get("window");
const NUM_COLUMNS = 3;
const ITEM_SIZE   = (width - 4) / NUM_COLUMNS;

// ─── Shimmer placeholder ──────────────────────────────────────────────────────

function ShimmerCard() {
  const colors  = useColors();
  const opacity = React.useRef(new Animated.Value(0.4)).current;

  React.useEffect(() => {
    const anim = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 1,   duration: 800, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.4, duration: 800, useNativeDriver: true }),
      ])
    );
    anim.start();
    return () => anim.stop();
  }, [opacity]);

  return (
    <Animated.View
      style={[styles.shimmerCard, { backgroundColor: colors.shimmer, opacity }]}
    />
  );
}

// ─── Individual status card ───────────────────────────────────────────────────

const StatusCard = React.memo(function StatusCard({
  item,
  onPress,
}: {
  item: StatusItem;
  onPress: () => void;
}) {
  const colors = useColors();
  const scale  = React.useRef(new Animated.Value(1)).current;

  const handlePressIn  = useCallback(() => {
    Animated.spring(scale, { toValue: 0.95, useNativeDriver: true, speed: 20 }).start();
  }, [scale]);

  const handlePressOut = useCallback(() => {
    Animated.spring(scale, { toValue: 1,    useNativeDriver: true, speed: 20 }).start();
  }, [scale]);

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Pressable
        onPress={onPress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        style={styles.card}
      >
        <Image
          source={{ uri: item.uri }}
          style={styles.thumbnail}
          contentFit="cover"
          transition={200}
          // onError is a no-op — broken images just show background color
        />
        {item.type === "video" && (
          <View style={styles.videoBadge}>
            <Feather name="play" size={12} color="#fff" />
          </View>
        )}
        {item.isSaved && (
          <View style={[styles.savedBadge, { backgroundColor: colors.primary }]}>
            <Feather name="check" size={10} color="#fff" />
          </View>
        )}
      </Pressable>
    </Animated.View>
  );
});

// ─── Grid ─────────────────────────────────────────────────────────────────────

export function StatusGrid({
  items,
  isLoading,
  onRefresh,
  onPress,
  emptyMessage = "No statuses found",
}: StatusGridProps) {
  const colors = useColors();

  // Runtime null-guard: never crash even if parent passes undefined
  const safeItems = useMemo(() => (Array.isArray(items) ? items : []), [items]);

  const renderItem = useCallback(
    ({ item, index }: { item: StatusItem; index: number }) => (
      <StatusCard item={item} onPress={() => onPress(item, index)} />
    ),
    [onPress]
  );

  const keyExtractor = useCallback((item: StatusItem) => item.id, []);

  // getItemLayout eliminates expensive layout measurement for fixed-size cells
  const getItemLayout = useCallback(
    (_: unknown, index: number) => ({
      length: ITEM_SIZE,
      offset: ITEM_SIZE * Math.floor(index / NUM_COLUMNS),
      index,
    }),
    []
  );

  if (isLoading) {
    return (
      <View style={styles.grid}>
        {Array.from({ length: 12 }).map((_, i) => (
          <ShimmerCard key={i} />
        ))}
      </View>
    );
  }

  if (safeItems.length === 0) {
    return (
      <View style={[styles.empty, { backgroundColor: colors.background }]}>
        <Feather name="image" size={52} color={colors.mutedForeground} />
        <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
          {emptyMessage}
        </Text>
        <Text style={[styles.emptySubtitle, { color: colors.mutedForeground }]}>
          Open WhatsApp, view some statuses, then pull down to refresh
        </Text>
      </View>
    );
  }

  return (
    <FlatList
      data={safeItems}
      renderItem={renderItem}
      keyExtractor={keyExtractor}
      numColumns={NUM_COLUMNS}
      getItemLayout={getItemLayout}
      // Performance tuning
      initialNumToRender={12}
      maxToRenderPerBatch={9}
      windowSize={5}
      removeClippedSubviews={Platform.OS === "android"}
      // UX
      contentContainerStyle={styles.listContent}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      refreshControl={
        <RefreshControl
          refreshing={false}
          onRefresh={onRefresh}
          tintColor={colors.primary}
          colors={[colors.primary]}
        />
      }
    />
  );
}

const styles = StyleSheet.create({
  grid:         { flexDirection: "row", flexWrap: "wrap" },
  listContent:  { paddingBottom: Platform.OS === "web" ? 34 : 80 },
  shimmerCard:  { width: ITEM_SIZE - 2, height: ITEM_SIZE - 2, margin: 1, borderRadius: 2 },
  card: {
    width: ITEM_SIZE - 2, height: ITEM_SIZE - 2, margin: 1,
    borderRadius: 2, overflow: "hidden", backgroundColor: "#e9edef",
  },
  thumbnail:  { width: "100%", height: "100%" },
  videoBadge: {
    position: "absolute", bottom: 6, right: 6,
    backgroundColor: "rgba(0,0,0,0.6)", borderRadius: 10, padding: 4,
  },
  savedBadge: { position: "absolute", top: 6, right: 6, borderRadius: 10, padding: 3 },
  empty: {
    flex: 1, alignItems: "center", justifyContent: "center",
    paddingHorizontal: 40, gap: 12,
  },
  emptyTitle:    { fontSize: 18, fontWeight: "600", textAlign: "center" },
  emptySubtitle: { fontSize: 14, textAlign: "center", lineHeight: 20 },
});
