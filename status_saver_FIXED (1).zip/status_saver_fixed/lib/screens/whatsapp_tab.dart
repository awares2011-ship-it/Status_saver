import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/status_provider.dart';
import '../utils/permission_utils.dart';
import '../widgets/banner_ad_widget.dart';
import '../widgets/permission_dialog.dart';
import 'images_fragment.dart';
import 'videos_fragment.dart';

class WhatsAppTab extends StatefulWidget {
  const WhatsAppTab({super.key});

  @override
  State<WhatsAppTab> createState() => _WhatsAppTabState();
}

class _WhatsAppTabState extends State<WhatsAppTab>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;


  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkPermission());
  }

  Future<void> _checkPermission() async {
    final hasPermission = await PermissionUtils.hasStoragePermission();
    if (!mounted) return;



    if (!hasPermission) {
      _showPermissionDialog();
    } else {
      final provider = context.read<StatusProvider>();
      if (provider.state == LoadState.idle) {
        provider.loadStatuses();
      }
    }
  }

  void _showPermissionDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => PermissionDialog(
        onGranted: () {
          Navigator.of(context).pop();
          context.read<StatusProvider>().loadStatuses();
        },
        onDenied: () => Navigator.of(context).pop(),
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final statusProvider = context.watch<StatusProvider>();
    final isMultiSelect = statusProvider.isMultiSelectMode;

    return Scaffold(
      appBar: AppBar(
        title: isMultiSelect
            ? Text('${statusProvider.selectedCount} selected')
            : const Text('Status Saver'),
        backgroundColor:
            isMultiSelect ? const Color(0xFF128C7E) : const Color(0xFF075E54),
        leading: isMultiSelect
            ? IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => statusProvider.clearSelection(),
              )
            : null,
        actions: [
          if (isMultiSelect) ...[
            IconButton(
              icon: const Icon(Icons.select_all),
              tooltip: 'Select All',
              onPressed: () {
                final list = _tabController.index == 0
                    ? statusProvider.imageStatuses
                    : statusProvider.videoStatuses;
                statusProvider.selectAll(list);
              },
            ),
          ] else ...[
            IconButton(
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'Refresh',
              onPressed: () => statusProvider.refresh(),
            ),
          ],
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.image_outlined, size: 18),
                  const SizedBox(width: 6),
                  Text(
                      'Images (${statusProvider.imageStatuses.length})'),
                ],
              ),
            ),
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.videocam_outlined, size: 18),
                  const SizedBox(width: 6),
                  Text(
                      'Videos (${statusProvider.videoStatuses.length})'),
                ],
              ),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: const [
                ImagesFragment(),
                VideosFragment(),
              ],
            ),
          ),
          const BannerAdWidget(adKey: 'home'),
        ],
      ),
    );
  }
}
