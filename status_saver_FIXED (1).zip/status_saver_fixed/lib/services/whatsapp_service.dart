import 'dart:io';
import 'package:flutter/foundation.dart';
import '../models/status_model.dart';
import '../utils/constants.dart';
import '../utils/file_utils.dart';

class WhatsAppService {
  WhatsAppService._();
  static final WhatsAppService instance = WhatsAppService._();

  /// Scans all known WA and WA Business status directories (legacy + scoped paths)
  /// and returns all unique statuses sorted newest-first.
  Future<List<StatusModel>> fetchAllStatuses() async {
    final List<StatusModel> statuses = [];
    final Set<String> seenFileNames = {};

    // Fix: scan all known paths for WhatsApp (legacy + Android 11+ scoped)
    for (final path in AppConstants.whatsappStatusPaths) {
      final files = await FileUtils.getWhatsAppStatusFiles(path);
      for (final file in files) {
        final fileName = file.path.split('/').last;
        if (!seenFileNames.contains(fileName)) {
          seenFileNames.add(fileName);
          statuses.add(_fileToStatus(file, isFromBusiness: false));
        }
      }
    }

    // Fix: scan all known paths for WhatsApp Business
    for (final path in AppConstants.whatsappBusinessStatusPaths) {
      final files = await FileUtils.getWhatsAppStatusFiles(path);
      for (final file in files) {
        final fileName = file.path.split('/').last;
        if (!seenFileNames.contains(fileName)) {
          seenFileNames.add(fileName);
          statuses.add(_fileToStatus(file, isFromBusiness: true));
        }
      }
    }

    // Sort by date descending
    statuses.sort((a, b) => b.date.compareTo(a.date));

    // Mark which are already saved
    final savedFiles = await FileUtils.getSavedFiles();
    final savedNames = savedFiles.map((f) => f.path.split('/').last).toSet();

    return statuses.map((s) {
      return s.copyWith(isSaved: savedNames.contains(s.fileName));
    }).toList();
  }

  StatusModel _fileToStatus(File file, {required bool isFromBusiness}) {
    final path = file.path;
    final lower = path.toLowerCase();
    final isVideo = AppConstants.videoExtensions.any((ext) => lower.endsWith(ext));

    return StatusModel(
      path: path,
      type: isVideo ? StatusType.video : StatusType.image,
      date: file.lastModifiedSync(),
      isFromBusiness: isFromBusiness,
    );
  }

  /// Returns true if any known WhatsApp status directory exists.
  Future<bool> isWhatsAppInstalled() async {
    for (final path in AppConstants.whatsappStatusPaths) {
      if (Directory(path).existsSync()) return true;
    }
    return false;
  }

  /// Returns true if any known WhatsApp Business status directory exists.
  Future<bool> isWhatsAppBusinessInstalled() async {
    for (final path in AppConstants.whatsappBusinessStatusPaths) {
      if (Directory(path).existsSync()) return true;
    }
    return false;
  }
}
