import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';

class PermissionUtils {
  PermissionUtils._();

  static int? _cachedSdkInt;

  /// Returns the Android SDK version integer (e.g. 33 for Android 13).
  /// Result is cached after the first call.
  static Future<int> _androidSdkVersion() async {
    if (_cachedSdkInt != null) return _cachedSdkInt!;
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      _cachedSdkInt = info.version.sdkInt;
    } catch (e) {
      if (kDebugMode) print('DeviceInfo error: $e');
      _cachedSdkInt = 0;
    }
    return _cachedSdkInt!;
  }

  /// Request all required storage permissions based on the real Android SDK version.
  static Future<bool> requestStoragePermission() async {
    if (!Platform.isAndroid) return true;

    try {
      final sdk = await _androidSdkVersion();

      if (sdk >= 33) {
        // Android 13+ — granular media permissions only
        final images = await Permission.photos.request();
        final videos = await Permission.videos.request();
        return images.isGranted && videos.isGranted;
      } else if (sdk >= 30) {
        // Android 11 & 12 — standard READ_EXTERNAL_STORAGE is sufficient
        // MANAGE_EXTERNAL_STORAGE is NOT requested (causes Play Store rejection)
        final storage = await Permission.storage.request();
        return storage.isGranted;
      } else {
        // Android < 11
        final storage = await Permission.storage.request();
        return storage.isGranted;
      }
    } catch (e) {
      if (kDebugMode) print('Permission error: $e');
      return false;
    }
  }

  /// Check if storage permission is already granted.
  static Future<bool> hasStoragePermission() async {
    if (!Platform.isAndroid) return true;

    try {
      final sdk = await _androidSdkVersion();

      if (sdk >= 33) {
        return await Permission.photos.isGranted &&
            await Permission.videos.isGranted;
      } else {
        return await Permission.storage.isGranted;
      }
    } catch (e) {
      if (kDebugMode) print('Permission check error: $e');
      return false;
    }
  }

  /// Check if any required permission is permanently denied.
  static Future<bool> isPermanentlyDenied() async {
    if (!Platform.isAndroid) return false;

    try {
      final sdk = await _androidSdkVersion();

      if (sdk >= 33) {
        return await Permission.photos.isPermanentlyDenied ||
            await Permission.videos.isPermanentlyDenied;
      } else {
        return await Permission.storage.isPermanentlyDenied;
      }
    } catch (e) {
      return false;
    }
  }

  /// Open app settings so the user can grant permission manually.
  static Future<void> openSettings() async {
    await openAppSettings();
  }
}
