# Status Saver — Save & Share
### Flutter Android App | AdMob Integrated | WhatsApp Green Theme

---

## 🐛 Bugs Fixed in This Version

| # | File | Severity | Issue | Fix |
|---|------|----------|-------|-----|
| 1 | `android/app/build.gradle` | 🔴 BUILD FAIL | Package namespace `com.yourcompany` didn't match `MainActivity.kt` `com.yourname` | Unified everywhere to `com.yourname.statussaver` |
| 2 | `android/build.gradle` | 🔴 BUILD FAIL | AGP `8.1.0` doesn't support `compileSdk 35` | Upgraded to AGP `8.3.2` |
| 3 | `gradle-wrapper.properties` | 🔴 BUILD FAIL | Gradle `8.3` too old for AGP `8.3.2` | Upgraded to Gradle `8.7` |
| 4 | `android/settings.gradle` | 🔴 BUILD FAIL | Hard `assert` crashes on fresh clone | Wrapped in `if` check |
| 5 | `android/app/build.gradle` | 🔴 CRASH | `null storeFile` in release signing crashes build | Falls back to debug signing when no keystore set |
| 6 | `proguard-rules.pro` | 🔴 RUNTIME CRASH | Only 4 keep rules with `minifyEnabled true` → `ClassNotFoundException` on all plugins | 38 keep/dontwarn rules covering all plugins |
| 7 | `lib/utils/file_utils.dart` | 🔴 DOUBLE-SAVE | `PhotoManager.editor.saveImageWithPath()` imports (copies) file again — duplicates in gallery | Replaced with `MethodChannel` → native `MediaScannerConnection` |
| 8 | `MainActivity.kt` | 🔴 CRASH | Package mismatch + no `MethodChannel` for media scan | Fixed package + added `MediaScannerConnection` channel |
| 9 | `lib/app.dart` | 🔴 COMPILE ERROR | Deprecated `background:` in `ColorScheme.fromSeed()` removed in Flutter 3.24+ | Removed both `background:` params |
| 10 | `lib/screens/settings_screen.dart` | 🟡 WARNING | Unused `colorScheme` + `isDark` variables | Removed |
| 11 | `lib/widgets/permission_dialog.dart` | 🟡 CRASH RISK | No `context.mounted` after every `await` | Added 6 mounted checks |
| 12 | `lib/screens/whatsapp_tab.dart` | 🟡 WARNING | `_permissionChecked` set but never read | Removed |
| 13 | `pubspec.yaml` | 🟡 UNUSED | `photo_manager` no longer needed | Removed |
| 14 | `AndroidManifest.xml` | 🟡 SHARE BROKEN | WhatsApp missing from `<queries>` — wouldn't appear in share sheet on Android 11+ | Added `<package android:name="com.whatsapp"/>` |

---

## 📁 Project Structure

```
status_saver/
├── pubspec.yaml
├── assets/images/splash_logo.png
│
├── lib/
│   ├── main.dart                        # Entry point + AdMob init + error handlers
│   ├── app.dart                         # MaterialApp + routes + WA green theme
│   │
│   ├── models/
│   │   └── status_model.dart
│   │
│   ├── providers/
│   │   ├── status_provider.dart         # WA status loading + multi-select
│   │   ├── saved_provider.dart          # Saved files CRUD
│   │   └── theme_provider.dart          # Dark/light mode
│   │
│   ├── services/
│   │   └── whatsapp_service.dart        # Scans WA + WA Business (legacy + scoped paths)
│   │
│   ├── utils/
│   │   ├── constants.dart               # Ad IDs, paths, config
│   │   ├── ad_manager.dart              # Singleton: banner/interstitial/native/app-open
│   │   ├── file_utils.dart              # Save/delete/list + MediaStore scan
│   │   └── permission_utils.dart        # device_info_plus-based SDK detection
│   │
│   ├── screens/
│   │   ├── splash_screen.dart
│   │   ├── home_screen.dart             # Bottom nav
│   │   ├── whatsapp_tab.dart            # Images / Videos TabBar
│   │   ├── images_fragment.dart         # Grid + shimmer + native ad every 6th
│   │   ├── videos_fragment.dart
│   │   ├── saved_screen.dart            # Saved grid + bulk delete/share
│   │   ├── image_viewer_screen.dart     # Pinch-zoom (photo_view)
│   │   ├── video_player_screen.dart     # Chewie player
│   │   └── settings_screen.dart
│   │
│   └── widgets/
│       ├── status_card.dart             # Grid card: download / share / multi-select
│       ├── native_ad_card.dart          # In-feed native ad
│       ├── banner_ad_widget.dart        # Bottom banner
│       ├── empty_state_widget.dart
│       └── permission_dialog.dart
│
└── android/
    ├── app/
    │   ├── build.gradle                 # compileSdk 35, AGP 8.3.2, safe signing
    │   ├── proguard-rules.pro           # 38 keep rules for all plugins
    │   └── src/main/
    │       ├── AndroidManifest.xml      # Permissions + AdMob + WA queries
    │       ├── kotlin/.../MainActivity.kt  # NativeAdFactory + MediaScanner channel
    │       └── res/layout/native_ad_layout.xml
    ├── build.gradle                     # AGP 8.3.2, Kotlin 1.9.22
    ├── settings.gradle                  # Safe (no hard assert)
    └── gradle/wrapper/gradle-wrapper.properties  # Gradle 8.7
```

---

## 🎨 Color Theme

| Role | Hex |
|------|-----|
| App Bar / Splash background | `#075E54` |
| Primary / Buttons / Badges | `#25D366` |
| Multi-select App Bar | `#128C7E` |
| Light background | `#F0F2F5` |
| Dark background | `#0B141A` |
| Dark surface / cards | `#1F2C34` |

---

## 💰 AdMob Test IDs

| Type | Unit ID |
|------|---------|
| App | `ca-app-pub-3940256099942544~3347511713` |
| Banner | `ca-app-pub-3940256099942544/6300978111` |
| Interstitial | `ca-app-pub-3940256099942544/1033173712` |
| Native | `ca-app-pub-3940256099942544/2247696110` |
| App Open | `ca-app-pub-3940256099942544/9257395921` |

> ⚠️ Replace ALL test IDs with your real AdMob IDs before publishing.

---

## 🚀 Build on EC2 Ubuntu

### Prerequisites
```bash
# Java 17
sudo apt update && sudo apt install -y openjdk-17-jdk
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64

# Flutter 3.22+
cd ~ && wget https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.22.0-stable.tar.xz
tar xf flutter_linux_3.22.0-stable.tar.xz
export PATH="$PATH:$HOME/flutter/bin"

# Android SDK
mkdir -p ~/android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-11076708_latest.zip -d ~/android-sdk/cmdline-tools/
mv ~/android-sdk/cmdline-tools/cmdline-tools ~/android-sdk/cmdline-tools/latest
export ANDROID_HOME=$HOME/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
yes | sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"
```

### Build
```bash
cd status_saver
flutter pub get
dart run flutter_native_splash:create
flutter build apk --release --split-per-abi
```

### Output APKs
```
build/app/outputs/flutter-apk/app-arm64-v8a-release.apk    ← most devices
build/app/outputs/flutter-apk/app-armeabi-v7a-release.apk  ← older 32-bit
build/app/outputs/flutter-apk/app-release.apk              ← universal
```

---

## 🔑 Before Publishing

1. Replace `com.yourname.statussaver` with your real package name in:
   - `android/app/build.gradle` (namespace + applicationId)
   - `android/app/src/main/kotlin/.../MainActivity.kt` (package declaration)
   - `lib/utils/constants.dart` (packageName + playStoreUrl)
   - `android/app/proguard-rules.pro`

2. Replace all AdMob test IDs in `lib/utils/constants.dart` and `AndroidManifest.xml`

3. Create and configure a release keystore in `local.properties`:
   ```
   keystore.path=/path/to/release.keystore
   keystore.password=yourpassword
   keystore.keyAlias=key0
   keystore.keyPassword=yourpassword
   ```

4. Replace `assets/images/splash_logo.png` with your real logo (1024×1024 PNG)

5. Update `privacyPolicyUrl` and `playStoreUrl` in `constants.dart`
