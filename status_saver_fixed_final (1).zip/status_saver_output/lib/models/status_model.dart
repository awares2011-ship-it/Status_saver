enum StatusType { image, video }

class StatusModel {
  final String path;
  final StatusType type;
  final DateTime date;
  final bool isSaved;
  final bool isFromBusiness;

  StatusModel({
    required this.path,
    required this.type,
    required this.date,
    this.isSaved = false,
    this.isFromBusiness = false,
  });

  String get fileName => path.split('/').last;

  StatusModel copyWith({
    String? path,
    StatusType? type,
    DateTime? date,
    bool? isSaved,
    bool? isFromBusiness,
  }) {
    return StatusModel(
      path: path ?? this.path,
      type: type ?? this.type,
      date: date ?? this.date,
      isSaved: isSaved ?? this.isSaved,
      isFromBusiness: isFromBusiness ?? this.isFromBusiness,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is StatusModel && other.path == path;
  }

  @override
  int get hashCode => path.hashCode;
}
