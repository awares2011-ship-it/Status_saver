import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/status_model.dart';
import '../providers/status_provider.dart';
import '../providers/saved_provider.dart';
import '../utils/ad_manager.dart';
import '../utils/constants.dart';
import '../widgets/status_card.dart';
import '../widgets/native_ad_card.dart';
import '../widgets/empty_state_widget.dart';
import 'package:shimmer/shimmer.dart';

class ImagesFragment extends StatelessWidget {
  const ImagesFragment({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<StatusProvider>(
      builder: (context, provider, _) {
        switch (provider.state) {
          case LoadState.idle:
            return const EmptyStateWidget(
              icon: Icons.image_search_rounded,
              title: 'No Statuses Yet',
              subtitle: 'Grant permission and tap refresh\nto load WhatsApp statuses.',
            );

          case LoadState.loading:
            return _buildShimmer(context);

          case LoadState.error:
            return EmptyStateWidget(
              icon: Icons.error_outline_rounded,
              title: 'Something went wrong',
              subtitle: provider.errorMessage ?? 'Please try again',
              actionLabel: 'Retry',
              onAction: () => provider.loadStatuses(),
            );

          case LoadState.loaded:
            final images = provider.imageStatuses;
            if (images.isEmpty) {
              return EmptyStateWidget(
                icon: Icons.photo_outlined,
                title: 'No Image Statuses',
                subtitle:
                    'Open WhatsApp and view some statuses,\nthen come back and refresh.',
                actionLabel: 'Refresh',
                onAction: () => provider.refreshStatuses(),
              );
            }

            final items = _buildItemsList(images);

            return RefreshIndicator(
              color: const Color(0xFF25D366),
              onRefresh: () => provider.refreshStatuses(),
              child: GridView.builder(
                padding: const EdgeInsets.all(4),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 4,
                  mainAxisSpacing: 4,
                  childAspectRatio: 0.8,
                ),
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final item = items[index];
                  if (item is _NativeAdSlot) {
                    return const NativeAdCard();
                  }
                  final status = item as StatusModel;
                  return StatusCard(
                    status: status,
                    isSelected: provider.isSelected(status.path),
                    isMultiSelectMode: provider.isMultiSelectMode,
                    onTap: () {
                      if (provider.isMultiSelectMode) {
                        provider.toggleSelection(status.path);
                      } else {
                        Navigator.of(context).pushNamed(
                          '/image_viewer',
                          arguments: status,
                        );
                      }
                    },
                    onLongPress: () => provider.toggleSelection(status.path),
                    onDownload: () async {
                      final savedProvider = context.read<SavedProvider>();
                      final ok = await savedProvider.saveStatus(status);
                      if (ok) {
                        provider.updateSavedState(status.path, true);
                        AdManager.instance.onDownloadAction();
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Row(
                                children: [
                                  Icon(Icons.check_circle,
                                      color: Colors.white, size: 20),
                                  SizedBox(width: 8),
                                  Text('Saved to StatusSaver folder'),
                                ],
                              ),
                            ),
                          );
                        }
                      }
                    },
                  );
                },
              ),
            );
        }
      },
    );
  }

  List<dynamic> _buildItemsList(List<StatusModel> statuses) {
    final items = <dynamic>[];
    for (int i = 0; i < statuses.length; i++) {
      if (i > 0 && i % AppConstants.nativeAdEveryN == 0) {
        items.add(_NativeAdSlot());
      }
      items.add(statuses[i]);
    }
    return items;
  }

  Widget _buildShimmer(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Shimmer.fromColors(
      baseColor: isDark ? Colors.grey[800]! : Colors.grey[300]!,
      highlightColor: isDark ? Colors.grey[700]! : Colors.grey[100]!,
      child: GridView.builder(
        padding: const EdgeInsets.all(4),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 4,
          mainAxisSpacing: 4,
          childAspectRatio: 0.8,
        ),
        itemCount: 12,
        itemBuilder: (_, __) => Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }
}

class _NativeAdSlot {}
