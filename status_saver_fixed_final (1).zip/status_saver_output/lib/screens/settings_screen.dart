import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../providers/theme_provider.dart';
import '../utils/constants.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _launchUrl(BuildContext context, String url) async {
    try {
      final uri = Uri.parse(url);
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Could not open link')),
          );
        }
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open link')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Fix: removed unused 'colorScheme' and top-level 'isDark' variables
    return Consumer<ThemeProvider>(
      builder: (context, themeProvider, _) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('Settings'),
            backgroundColor: const Color(0xFF075E54),
          ),
          body: ListView(
            padding: EdgeInsets.zero,
            children: [
              // App header card
              Container(
                color: const Color(0xFF075E54),
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
                child: Row(
                  children: [
                    Container(
                      width: 64,
                      height: 64,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.download_for_offline_rounded,
                        size: 40,
                        color: Color(0xFF25D366),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Status Saver',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Version ${AppConstants.appVersion}',
                          style: const TextStyle(
                            color: Colors.white70,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),
              _SectionHeader(title: 'Preferences'),

              _SettingsTile(
                icon: Icons.dark_mode_rounded,
                iconColor: const Color(0xFF7C3AED),
                title: 'Dark Mode',
                subtitle: themeProvider.isDarkMode ? 'On' : 'Off',
                trailing: Switch(
                  value: themeProvider.isDarkMode,
                  onChanged: (_) => themeProvider.toggleDarkMode(),
                ),
              ),

              _SettingsTile(
                icon: Icons.auto_awesome_rounded,
                iconColor: const Color(0xFF25D366),
                title: 'Auto-Save Statuses',
                subtitle: themeProvider.autoSave
                    ? 'New statuses auto-saved'
                    : 'Manual save only',
                trailing: Switch(
                  value: themeProvider.autoSave,
                  onChanged: (_) => themeProvider.toggleAutoSave(),
                ),
              ),

              const SizedBox(height: 8),
              _SectionHeader(title: 'About'),

              _SettingsTile(
                icon: Icons.star_rounded,
                iconColor: const Color(0xFFF59E0B),
                title: 'Rate Us',
                subtitle: 'Enjoy the app? Rate us on Play Store',
                onTap: () => _launchUrl(context, AppConstants.playStoreUrl),
              ),

              _SettingsTile(
                icon: Icons.privacy_tip_rounded,
                iconColor: const Color(0xFF0EA5E9),
                title: 'Privacy Policy',
                subtitle: 'Read our privacy policy',
                onTap: () => _launchUrl(context, AppConstants.privacyPolicyUrl),
              ),

              _SettingsTile(
                icon: Icons.info_rounded,
                iconColor: Colors.grey,
                title: 'App Version',
                subtitle: AppConstants.appVersion,
              ),

              const SizedBox(height: 8),
              _SectionHeader(title: 'How to Use'),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _HowToStep(
                          step: '1',
                          text: 'Open WhatsApp and view the statuses you want to save.',
                        ),
                        const SizedBox(height: 10),
                        _HowToStep(
                          step: '2',
                          text: 'Come back to Status Saver and tap Refresh.',
                        ),
                        const SizedBox(height: 10),
                        _HowToStep(
                          step: '3',
                          text: 'Tap the download icon on any status to save it.',
                        ),
                        const SizedBox(height: 10),
                        _HowToStep(
                          step: '4',
                          text: 'Find saved statuses in the Saved tab or in Pictures/StatusSaver.',
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 32),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  'This app is not affiliated with WhatsApp Inc. Always get permission before reposting others\' statuses.',
                  style: TextStyle(
                    color: Colors.grey[500],
                    fontSize: 11,
                    height: 1.5,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        );
      },
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          color: Color(0xFF25D366),
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title;
  final String subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;

  const _SettingsTile({
    required this.icon,
    required this.iconColor,
    required this.title,
    required this.subtitle,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 3),
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        color: isDark ? const Color(0xFF1F2C34) : Colors.white,
        child: ListTile(
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          leading: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: iconColor, size: 22),
          ),
          title: Text(
            title,
            style: TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 15,
              color: isDark ? Colors.white : Colors.black87,
            ),
          ),
          subtitle: Text(
            subtitle,
            style: TextStyle(fontSize: 12, color: Colors.grey[500]),
          ),
          trailing: trailing ??
              (onTap != null
                  ? Icon(Icons.chevron_right_rounded, color: Colors.grey[400])
                  : null),
          onTap: onTap,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }
}

class _HowToStep extends StatelessWidget {
  final String step;
  final String text;
  const _HowToStep({required this.step, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 24,
          height: 24,
          decoration: const BoxDecoration(
            color: Color(0xFF25D366),
            shape: BoxShape.circle,
          ),
          alignment: Alignment.center,
          child: Text(
            step,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              fontSize: 13,
              color: Colors.grey[600],
              height: 1.4,
            ),
          ),
        ),
      ],
    );
  }
}
