import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/status_model.dart';
import '../providers/saved_provider.dart';
import '../widgets/status_card.dart';
import '../widgets/empty_state_widget.dart';
import '../widgets/banner_ad_widget.dart';

class SavedScreen extends StatefulWidget {
  const SavedScreen({super.key});

  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<SavedProvider>().loadSaved();
    });
  }

  Future<void> _confirmDelete(SavedProvider provider) async {
    final count = provider.selectedCount;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Statuses'),
        content: Text(
          'Are you sure you want to delete $count ${count == 1 ? 'status' : 'statuses'}?',
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (ok == true && mounted) {
      final deleted = await provider.deleteSelected();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$deleted ${deleted == 1 ? 'status' : 'statuses'} deleted'),
          ),
        );
      }
    }
  }

  Future<void> _shareSelected(SavedProvider provider) async {
    final paths = provider.selectedStatuses.map((s) => XFile(s.path)).toList();
    if (paths.isEmpty) return;
    await Share.shareXFiles(paths, text: 'Shared via Status Saver');
    provider.clearSelection();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<SavedProvider>(
      builder: (context, provider, _) {
        final isMultiSelect = provider.isMultiSelectMode;

        return Scaffold(
          appBar: AppBar(
            title: isMultiSelect
                ? Text('${provider.selectedCount} selected')
                : const Text('Saved'),
            backgroundColor: isMultiSelect
                ? const Color(0xFF128C7E)
                : const Color(0xFF075E54),
            leading: isMultiSelect
                ? IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: provider.clearSelection,
                  )
                : null,
            actions: [
              if (isMultiSelect) ...[
                IconButton(
                  icon: const Icon(Icons.share_outlined),
                  tooltip: 'Share',
                  onPressed: () => _shareSelected(provider),
                ),
                IconButton(
                  icon: const Icon(Icons.delete_outline_rounded),
                  tooltip: 'Delete',
                  onPressed: () => _confirmDelete(provider),
                ),
                IconButton(
                  icon: const Icon(Icons.select_all),
                  tooltip: 'Select All',
                  onPressed: provider.selectAll,
                ),
              ] else ...[
                IconButton(
                  icon: const Icon(Icons.refresh_rounded),
                  onPressed: provider.loadSaved,
                ),
              ],
            ],
          ),
          body: Column(
            children: [
              Expanded(
                child: provider.isLoading
                    ? const Center(
                        child: CircularProgressIndicator(
                          color: Color(0xFF25D366),
                        ),
                      )
                    : provider.savedStatuses.isEmpty
                        ? const EmptyStateWidget(
                            icon: Icons.save_alt_rounded,
                            title: 'No Saved Statuses',
                            subtitle:
                                'Save statuses from the WhatsApp\ntab to see them here.',
                          )
                        : RefreshIndicator(
                            color: const Color(0xFF25D366),
                            onRefresh: provider.loadSaved,
                            child: GridView.builder(
                              padding: const EdgeInsets.all(4),
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3,
                                crossAxisSpacing: 4,
                                mainAxisSpacing: 4,
                                childAspectRatio: 0.8,
                              ),
                              itemCount: provider.savedStatuses.length,
                              itemBuilder: (context, index) {
                                final status = provider.savedStatuses[index];
                                return StatusCard(
                                  status: status,
                                  isSelected: provider.isSelected(status.path),
                                  isMultiSelectMode: isMultiSelect,
                                  showDeleteButton: !isMultiSelect,
                                  onTap: () {
                                    if (isMultiSelect) {
                                      provider.toggleSelection(status.path);
                                    } else {
                                      Navigator.of(context).pushNamed(
                                        status.type == StatusType.video
                                            ? '/video_player'
                                            : '/image_viewer',
                                        arguments: status,
                                      );
                                    }
                                  },
                                  onLongPress: () =>
                                      provider.toggleSelection(status.path),
                                  onDelete: () async {
                                    final ok =
                                        await provider.deleteStatus(status);
                                    if (ok && context.mounted) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        const SnackBar(
                                          content: Text('Status deleted'),
                                        ),
                                      );
                                    }
                                  },
                                );
                              },
                            ),
                          ),
              ),
              const BannerAdWidget(adKey: 'saved'),
            ],
          ),
        );
      },
    );
  }
}
