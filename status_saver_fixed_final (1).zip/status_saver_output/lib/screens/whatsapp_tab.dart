import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/status_provider.dart';
import '../utils/permission_utils.dart';
import '../widgets/banner_ad_widget.dart';
import 'images_fragment.dart';
import 'videos_fragment.dart';

class WhatsAppTab extends StatefulWidget {
  const WhatsAppTab({super.key});

  @override
  State<WhatsAppTab> createState() => _WhatsAppTabState();
}

class _WhatsAppTabState extends State<WhatsAppTab>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _permissionGranted = false;
  bool _checkingPermission = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    // Only CHECK (no request) — never block UI or auto-request
    _checkExistingPermission();
  }

  /// Silently check if permission already exists — do NOT request here.
  Future<void> _checkExistingPermission() async {
    final hasPermission = await PermissionUtils.hasStoragePermission();
    if (!mounted) return;
    setState(() {
      _permissionGranted = hasPermission;
      _checkingPermission = false;
    });
    if (hasPermission) {
      final provider = context.read<StatusProvider>();
      if (provider.state == LoadState.idle) {
        provider.loadStatuses();
      }
    }
  }

  /// Called when user explicitly taps "Grant Permission" button.
  Future<void> _requestPermission() async {
    final isPermanent = await PermissionUtils.isPermanentlyDenied();
    if (isPermanent) {
      if (!mounted) return;
      _showOpenSettingsDialog();
      return;
    }

    final granted = await PermissionUtils.requestStoragePermission();
    if (!mounted) return;

    setState(() => _permissionGranted = granted);

    if (granted) {
      context.read<StatusProvider>().loadStatuses();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Permission denied. Please grant storage access.'),
          action: SnackBarAction(
            label: 'Settings',
            onPressed: PermissionUtils.openSettings,
          ),
        ),
      );
    }
  }

  void _showOpenSettingsDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Permission Required'),
        content: const Text(
          'Storage permission was permanently denied.\n\nPlease open Settings and grant "Files and media" permission to load WhatsApp statuses.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF25D366),
              foregroundColor: Colors.white,
            ),
            onPressed: () {
              Navigator.of(ctx).pop();
              PermissionUtils.openSettings();
            },
            child: const Text('Open Settings'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final statusProvider = context.watch<StatusProvider>();
    final isMultiSelect = statusProvider.isMultiSelectMode;

    return Scaffold(
      appBar: AppBar(
        title: isMultiSelect
            ? Text('${statusProvider.selectedCount} selected')
            : const Text('Status Saver'),
        backgroundColor:
            isMultiSelect ? const Color(0xFF128C7E) : const Color(0xFF075E54),
        foregroundColor: Colors.white,
        leading: isMultiSelect
            ? IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => statusProvider.clearSelection(),
              )
            : null,
        actions: [
          if (isMultiSelect) ...[
            IconButton(
              icon: const Icon(Icons.select_all),
              tooltip: 'Select All',
              onPressed: () {
                final list = _tabController.index == 0
                    ? statusProvider.imageStatuses
                    : statusProvider.videoStatuses;
                statusProvider.selectAll(list);
              },
            ),
          ] else ...[
            IconButton(
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'Refresh',
              onPressed: _permissionGranted
                  ? () => statusProvider.refreshStatuses()
                  : _requestPermission,
            ),
          ],
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: const Color(0xFF25D366),
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: [
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.image_outlined, size: 18),
                  const SizedBox(width: 6),
                  Text('Images (${statusProvider.imageStatuses.length})'),
                ],
              ),
            ),
            Tab(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.videocam_outlined, size: 18),
                  const SizedBox(width: 6),
                  Text('Videos (${statusProvider.videoStatuses.length})'),
                ],
              ),
            ),
          ],
        ),
      ),
      body: _checkingPermission
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF25D366)),
            )
          : !_permissionGranted
              ? _buildPermissionRequired()
              : Column(
                  children: [
                    Expanded(
                      child: TabBarView(
                        controller: _tabController,
                        children: const [
                          ImagesFragment(),
                          VideosFragment(),
                        ],
                      ),
                    ),
                    const BannerAdWidget(adKey: 'home'),
                  ],
                ),
    );
  }

  Widget _buildPermissionRequired() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                color: const Color(0xFF25D366).withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.lock_outline_rounded,
                size: 44,
                color: Color(0xFF25D366),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Permission Required',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            const Text(
              'Permission is required to access WhatsApp statuses on your device.',
              style: TextStyle(
                fontSize: 15,
                color: Colors.grey,
                height: 1.5,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.storage_rounded),
                label: const Text(
                  'Grant Permission',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF25D366),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  elevation: 2,
                ),
                onPressed: _requestPermission,
              ),
            ),
            const SizedBox(height: 16),
            TextButton(
              onPressed: PermissionUtils.openSettings,
              child: const Text(
                'Open App Settings',
                style: TextStyle(color: Colors.grey),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
