import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/status_model.dart';
import '../providers/saved_provider.dart';
import '../utils/ad_manager.dart';

class VideoPlayerScreen extends StatefulWidget {
  final StatusModel status;
  const VideoPlayerScreen({super.key, required this.status});

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  VideoPlayerController? _videoPlayerController;
  ChewieController? _chewieController;
  bool _isInitialized = false;
  bool _hasError = false;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _initPlayer();
  }

  Future<void> _initPlayer() async {
    // Fix: guard the whole init so a navigate-away during load doesn't crash
    try {
      final file = File(widget.status.path);
      if (!await file.exists()) {
        if (!mounted) return;
        setState(() => _hasError = true);
        return;
      }

      _videoPlayerController = VideoPlayerController.file(file);
      await _videoPlayerController!.initialize();

      // Fix: always check mounted after any await before calling setState
      if (!mounted) {
        _videoPlayerController?.dispose();
        return;
      }

      _chewieController = ChewieController(
        videoPlayerController: _videoPlayerController!,
        autoPlay: true,
        looping: true,
        allowFullScreen: true,
        allowMuting: true,
        showControlsOnInitialize: true,
        placeholder: const Center(
          child: CircularProgressIndicator(color: Color(0xFF25D366)),
        ),
        materialProgressColors: ChewieProgressColors(
          playedColor: const Color(0xFF25D366),
          handleColor: const Color(0xFF25D366),
          backgroundColor: Colors.white24,
          bufferedColor: Colors.white38,
        ),
        errorBuilder: (context, errorMessage) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline_rounded,
                    color: Colors.white54, size: 64),
                const SizedBox(height: 12),
                Text(
                  'Error: $errorMessage',
                  style: const TextStyle(color: Colors.white54),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          );
        },
      );

      setState(() => _isInitialized = true);
    } catch (e) {
      // Fix: mounted check before setState in catch block
      if (!mounted) return;
      setState(() => _hasError = true);
      debugPrint('VideoPlayer init error: $e');
    }
  }

  Future<void> _saveStatus() async {
    if (_isSaving) return;
    setState(() => _isSaving = true);

    final savedProvider = context.read<SavedProvider>();
    final ok = await savedProvider.saveStatus(widget.status);

    // Fix: mounted check after await
    if (!mounted) return;
    setState(() => _isSaving = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              ok ? Icons.check_circle : Icons.error_outline,
              color: Colors.white,
              size: 20,
            ),
            const SizedBox(width: 8),
            Text(ok ? 'Video saved to StatusSaver!' : 'Save failed.'),
          ],
        ),
      ),
    );
    if (ok) AdManager.instance.onDownloadAction();
  }

  Future<void> _shareStatus() async {
    try {
      await Share.shareXFiles(
        [XFile(widget.status.path)],
        text: 'Shared via Status Saver',
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not share file')),
      );
    }
  }

  @override
  void dispose() {
    _chewieController?.dispose();
    _videoPlayerController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(
          widget.status.fileName,
          style: const TextStyle(fontSize: 14, color: Colors.white),
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share_rounded),
            onPressed: _shareStatus,
          ),
          IconButton(
            icon: _isSaving
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    ),
                  )
                : Icon(
                    widget.status.isSaved
                        ? Icons.check_circle_rounded
                        : Icons.download_rounded,
                  ),
            onPressed: widget.status.isSaved ? null : _saveStatus,
            tooltip: widget.status.isSaved ? 'Already saved' : 'Save',
          ),
        ],
      ),
      body: _hasError
          ? const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.videocam_off_outlined,
                      color: Colors.white54, size: 72),
                  SizedBox(height: 16),
                  Text(
                    'Unable to play this video',
                    style: TextStyle(color: Colors.white54, fontSize: 16),
                  ),
                ],
              ),
            )
          : !_isInitialized
              ? const Center(
                  child: CircularProgressIndicator(color: Color(0xFF25D366)),
                )
              : Column(
                  children: [
                    Expanded(
                      child: Chewie(controller: _chewieController!),
                    ),
                    if (!widget.status.isSaved)
                      Container(
                        color: Colors.black87,
                        padding: const EdgeInsets.symmetric(
                            vertical: 12, horizontal: 16),
                        child: Row(
                          children: [
                            const Icon(Icons.info_outline,
                                color: Colors.white70, size: 16),
                            const SizedBox(width: 8),
                            const Expanded(
                              child: Text(
                                'Tap download to save this video',
                                style: TextStyle(
                                    color: Colors.white70, fontSize: 13),
                              ),
                            ),
                            ElevatedButton.icon(
                              onPressed: _isSaving ? null : _saveStatus,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF25D366),
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20)),
                              ),
                              icon: _isSaving
                                  ? const SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: CircularProgressIndicator(
                                          color: Colors.white, strokeWidth: 2),
                                    )
                                  : const Icon(Icons.download_rounded,
                                      size: 18),
                              label: Text(_isSaving ? 'Saving...' : 'Save'),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
    );
  }
}
