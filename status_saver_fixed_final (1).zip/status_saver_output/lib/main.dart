import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'providers/status_provider.dart';
import 'providers/saved_provider.dart';
import 'providers/theme_provider.dart';
import 'utils/ad_manager.dart';

void main() async {
  // Fix: global error handlers must be registered before runApp
  WidgetsFlutterBinding.ensureInitialized();

  // Fix: catch Flutter framework errors (layout, rendering, etc.)
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
    // TODO: replace with your crash reporting (e.g. Firebase Crashlytics):
    // FirebaseCrashlytics.instance.recordFlutterFatalError(details);
    debugPrint('FlutterError: ${details.exceptionAsString()}');
  };

  // Fix: catch all other uncaught async errors (Dart isolate errors)
  PlatformDispatcher.instance.onError = (Object error, StackTrace stack) {
    // TODO: replace with your crash reporting:
    // FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
    debugPrint('Uncaught error: $error\n$stack');
    return true; // returning true means "I handled this, don't crash"
  };

  // Initialize AdMob
  await MobileAds.instance.initialize();

  // Lock to portrait
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  final prefs = await SharedPreferences.getInstance();

  // Initialize AdManager (registers lifecycle observer internally)
  AdManager.instance.initialize();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => ThemeProvider(prefs)),
        ChangeNotifierProvider(create: (_) => StatusProvider()),
        ChangeNotifierProvider(create: (_) => SavedProvider()),
      ],
      child: const StatusSaverApp(),
    ),
  );
}
