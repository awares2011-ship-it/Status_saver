import 'dart:io';
import 'package:flutter/foundation.dart';
import '../models/status_model.dart';

class WhatsAppService {
  WhatsAppService._();
  static final WhatsAppService instance = WhatsAppService._();

  // All known WhatsApp status directory paths (Android 10 legacy + Android 11+ scoped)
  static const List<String> _waPaths = [
    '/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/.Statuses',
    '/storage/emulated/0/WhatsApp/Media/.Statuses',
  ];

  static const List<String> _waBizPaths = [
    '/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses',
    '/storage/emulated/0/WhatsApp Business/Media/.Statuses',
  ];

  static const List<String> _imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
  static const List<String> _videoExtensions = ['.mp4', '.mkv', '.avi', '.mov', '.3gp'];

  /// Scans all known WA and WA Business status directories
  /// and returns all unique statuses sorted newest-first.
  Future<List<StatusModel>> fetchAllStatuses() async {
    final List<StatusModel> statuses = [];
    final Set<String> seenFileNames = {};

    for (final path in _waPaths) {
      final files = await _listStatusFiles(path);
      for (final file in files) {
        final fileName = file.path.split('/').last;
        if (!seenFileNames.contains(fileName)) {
          seenFileNames.add(fileName);
          statuses.add(_fileToStatus(file, isFromBusiness: false));
        }
      }
    }

    for (final path in _waBizPaths) {
      final files = await _listStatusFiles(path);
      for (final file in files) {
        final fileName = file.path.split('/').last;
        if (!seenFileNames.contains(fileName)) {
          seenFileNames.add(fileName);
          statuses.add(_fileToStatus(file, isFromBusiness: true));
        }
      }
    }

    // Sort by modified date descending (newest first)
    statuses.sort((a, b) => b.date.compareTo(a.date));

    // Mark already-saved files
    final savedNames = await _getSavedFileNames();
    return statuses.map((s) {
      return s.copyWith(isSaved: savedNames.contains(s.fileName));
    }).toList();
  }

  /// Safely lists media files from a directory.
  Future<List<File>> _listStatusFiles(String dirPath) async {
    try {
      final dir = Directory(dirPath);
      if (!dir.existsSync()) {
        if (kDebugMode) print('[WhatsAppService] Dir not found: $dirPath');
        return [];
      }

      final List<FileSystemEntity> entities;
      try {
        entities = dir.listSync(followLinks: false);
      } on FileSystemException catch (e) {
        if (kDebugMode) print('[WhatsAppService] Permission denied: $dirPath — $e');
        return [];
      }

      final files = entities.whereType<File>().where((f) {
        final name = f.path.split('/').last;
        // Skip hidden files and .nomedia
        if (name.startsWith('.') || name == '.nomedia') return false;
        final lower = f.path.toLowerCase();
        return _imageExtensions.any((ext) => lower.endsWith(ext)) ||
            _videoExtensions.any((ext) => lower.endsWith(ext));
      }).toList();

      files.sort((a, b) {
        try {
          return b.lastModifiedSync().compareTo(a.lastModifiedSync());
        } catch (_) {
          return 0;
        }
      });

      if (kDebugMode) {
        print('[WhatsAppService] Found ${files.length} files in $dirPath');
      }

      return files;
    } catch (e) {
      if (kDebugMode) print('[WhatsAppService] Error reading $dirPath: $e');
      return [];
    }
  }

  StatusModel _fileToStatus(File file, {required bool isFromBusiness}) {
    final path = file.path;
    final lower = path.toLowerCase();
    final isVideo = _videoExtensions.any((ext) => lower.endsWith(ext));

    DateTime date;
    try {
      date = file.lastModifiedSync();
    } catch (_) {
      date = DateTime.now();
    }

    return StatusModel(
      path: path,
      type: isVideo ? StatusType.video : StatusType.image,
      date: date,
      isFromBusiness: isFromBusiness,
    );
  }

  Future<Set<String>> _getSavedFileNames() async {
    try {
      const savePath = '/storage/emulated/0/Pictures/StatusSaver';
      final dir = Directory(savePath);
      if (!dir.existsSync()) return {};
      return dir
          .listSync()
          .whereType<File>()
          .map((f) => f.path.split('/').last)
          .toSet();
    } catch (_) {
      return {};
    }
  }

  /// Returns true if any known WhatsApp status directory exists.
  Future<bool> isWhatsAppInstalled() async {
    for (final path in _waPaths) {
      if (Directory(path).existsSync()) return true;
    }
    return false;
  }

  /// Returns true if any known WhatsApp Business status directory exists.
  Future<bool> isWhatsAppBusinessInstalled() async {
    for (final path in _waBizPaths) {
      if (Directory(path).existsSync()) return true;
    }
    return false;
  }
}
