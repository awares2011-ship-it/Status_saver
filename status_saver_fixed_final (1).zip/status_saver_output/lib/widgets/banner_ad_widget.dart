import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../utils/ad_manager.dart';

class BannerAdWidget extends StatefulWidget {
  final String adKey; // 'home' or 'saved'
  const BannerAdWidget({super.key, required this.adKey});

  @override
  State<BannerAdWidget> createState() => _BannerAdWidgetState();
}

class _BannerAdWidgetState extends State<BannerAdWidget> {
  bool _isLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadBanner();
  }

  void _loadBanner() {
    if (widget.adKey == 'home') {
      AdManager.instance.loadHomeBanner(onLoaded: () {
        if (mounted) setState(() => _isLoaded = true);
      });
    } else {
      AdManager.instance.loadSavedBanner(onLoaded: () {
        if (mounted) setState(() => _isLoaded = true);
      });
    }
  }

  @override
  void dispose() {
    if (widget.adKey == 'home') {
      AdManager.instance.disposeHomeBanner();
    } else {
      AdManager.instance.disposeSavedBanner();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ad = widget.adKey == 'home'
        ? AdManager.instance.homeBannerAd
        : AdManager.instance.savedBannerAd;

    if (!_isLoaded || ad == null) {
      return const SizedBox.shrink();
    }

    return SafeArea(
      top: false,
      child: Container(
        alignment: Alignment.center,
        width: ad.size.width.toDouble(),
        height: ad.size.height.toDouble(),
        child: AdWidget(ad: ad),
      ),
    );
  }
}
