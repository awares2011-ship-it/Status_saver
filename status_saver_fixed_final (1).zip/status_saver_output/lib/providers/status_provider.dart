import 'package:flutter/foundation.dart';
import '../models/status_model.dart';
import '../services/whatsapp_service.dart';

enum LoadState { idle, loading, loaded, error }

class StatusProvider extends ChangeNotifier {
  List<StatusModel> _allStatuses = [];
  LoadState _state = LoadState.idle;
  String? _errorMessage;
  Set<String> _selectedPaths = {};
  bool _isMultiSelectMode = false;

  List<StatusModel> get imageStatuses =>
      _allStatuses.where((s) => s.type == StatusType.image).toList();

  List<StatusModel> get videoStatuses =>
      _allStatuses.where((s) => s.type == StatusType.video).toList();

  List<StatusModel> get allStatuses => _allStatuses;
  LoadState get state => _state;
  String? get errorMessage => _errorMessage;
  Set<String> get selectedPaths => _selectedPaths;
  bool get isMultiSelectMode => _isMultiSelectMode;
  int get selectedCount => _selectedPaths.length;
  int get newStatusCount => _allStatuses.where((s) => !s.isSaved).length;

  List<StatusModel> get selectedStatuses =>
      _allStatuses.where((s) => _selectedPaths.contains(s.path)).toList();

  bool get isLoading => _state == LoadState.loading;

  Future<void> loadStatuses() async {
    // Prevent double-loading
    if (_state == LoadState.loading) return;

    _state = LoadState.loading;
    _errorMessage = null;
    notifyListeners();

    try {
      final fetched = await WhatsAppService.instance.fetchAllStatuses();
      _allStatuses = fetched;
      _state = LoadState.loaded;
    } catch (e) {
      _state = LoadState.error;
      _errorMessage = 'Failed to load statuses: $e';
      if (kDebugMode) print(_errorMessage);
    }

    notifyListeners();
  }

  /// Alias for loadStatuses — called by refresh button / pull-to-refresh.
  Future<void> refreshStatuses() async {
    clearSelection();
    await loadStatuses();
  }

  /// Legacy alias kept for backward compatibility.
  Future<void> refresh() async => refreshStatuses();

  void updateSavedState(String path, bool isSaved) {
    final index = _allStatuses.indexWhere((s) => s.path == path);
    if (index != -1) {
      _allStatuses[index] = _allStatuses[index].copyWith(isSaved: isSaved);
      notifyListeners();
    }
  }

  void toggleSelection(String path) {
    if (_selectedPaths.contains(path)) {
      _selectedPaths.remove(path);
    } else {
      _selectedPaths.add(path);
    }
    _isMultiSelectMode = _selectedPaths.isNotEmpty;
    notifyListeners();
  }

  void selectAll(List<StatusModel> statuses) {
    _selectedPaths = statuses.map((s) => s.path).toSet();
    _isMultiSelectMode = _selectedPaths.isNotEmpty;
    notifyListeners();
  }

  void clearSelection() {
    _selectedPaths.clear();
    _isMultiSelectMode = false;
    notifyListeners();
  }

  bool isSelected(String path) => _selectedPaths.contains(path);
}
