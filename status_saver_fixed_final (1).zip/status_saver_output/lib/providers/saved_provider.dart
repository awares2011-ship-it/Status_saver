import 'dart:io';
import 'package:flutter/foundation.dart';
import '../models/status_model.dart';
import '../utils/file_utils.dart';
import '../utils/constants.dart';

class SavedProvider extends ChangeNotifier {
  List<StatusModel> _savedStatuses = [];
  bool _isLoading = false;
  Set<String> _selectedPaths = {};
  bool _isMultiSelectMode = false;

  List<StatusModel> get savedStatuses => _savedStatuses;
  List<StatusModel> get savedImages =>
      _savedStatuses.where((s) => s.type == StatusType.image).toList();
  List<StatusModel> get savedVideos =>
      _savedStatuses.where((s) => s.type == StatusType.video).toList();
  bool get isLoading => _isLoading;
  Set<String> get selectedPaths => _selectedPaths;
  bool get isMultiSelectMode => _isMultiSelectMode;
  int get selectedCount => _selectedPaths.length;

  List<StatusModel> get selectedStatuses =>
      _savedStatuses.where((s) => _selectedPaths.contains(s.path)).toList();

  Future<void> loadSaved() async {
    _isLoading = true;
    notifyListeners();

    try {
      final files = await FileUtils.getSavedFiles();
      _savedStatuses = files.map((file) {
        final path = file.path;
        final lower = path.toLowerCase();
        final isVideo =
            AppConstants.videoExtensions.any((ext) => lower.endsWith(ext));
        return StatusModel(
          path: path,
          type: isVideo ? StatusType.video : StatusType.image,
          date: file.lastModifiedSync(),
          isSaved: true,
        );
      }).toList();
    } catch (e) {
      if (kDebugMode) print('Error loading saved: $e');
      _savedStatuses = [];
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<bool> saveStatus(StatusModel status) async {
    try {
      final savedPath = await FileUtils.saveStatus(status.path);
      if (savedPath != null) {
        final file = File(savedPath);
        final isVideo = FileUtils.isVideo(savedPath);
        final saved = StatusModel(
          path: savedPath,
          type: isVideo ? StatusType.video : StatusType.image,
          date: file.lastModifiedSync(),
          isSaved: true,
        );
        // Add to front if not already there
        if (!_savedStatuses.any((s) => s.path == savedPath)) {
          _savedStatuses.insert(0, saved);
          notifyListeners();
        }
        return true;
      }
      return false;
    } catch (e) {
      if (kDebugMode) print('Error saving status: $e');
      return false;
    }
  }

  Future<int> saveMultiple(List<StatusModel> statuses) async {
    int count = 0;
    for (final status in statuses) {
      final ok = await saveStatus(status);
      if (ok) count++;
    }
    return count;
  }

  Future<bool> deleteStatus(StatusModel status) async {
    try {
      final ok = await FileUtils.deleteFile(status.path);
      if (ok) {
        _savedStatuses.removeWhere((s) => s.path == status.path);
        _selectedPaths.remove(status.path);
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      if (kDebugMode) print('Error deleting status: $e');
      return false;
    }
  }

  Future<int> deleteSelected() async {
    final toDelete = List<StatusModel>.from(selectedStatuses);
    int count = 0;
    for (final status in toDelete) {
      final ok = await deleteStatus(status);
      if (ok) count++;
    }
    clearSelection();
    return count;
  }

  void toggleSelection(String path) {
    if (_selectedPaths.contains(path)) {
      _selectedPaths.remove(path);
    } else {
      _selectedPaths.add(path);
    }
    _isMultiSelectMode = _selectedPaths.isNotEmpty;
    notifyListeners();
  }

  void selectAll() {
    _selectedPaths = _savedStatuses.map((s) => s.path).toSet();
    _isMultiSelectMode = _selectedPaths.isNotEmpty;
    notifyListeners();
  }

  void clearSelection() {
    _selectedPaths.clear();
    _isMultiSelectMode = false;
    notifyListeners();
  }

  bool isSelected(String path) => _selectedPaths.contains(path);
}
