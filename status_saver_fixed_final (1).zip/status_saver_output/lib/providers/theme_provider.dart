import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';

class ThemeProvider extends ChangeNotifier {
  final SharedPreferences _prefs;
  late bool _isDarkMode;
  late bool _autoSave;

  ThemeProvider(this._prefs) {
    _isDarkMode = _prefs.getBool(AppConstants.prefDarkMode) ?? false;
    _autoSave = _prefs.getBool(AppConstants.prefAutoSave) ?? false;
  }

  bool get isDarkMode => _isDarkMode;
  bool get autoSave => _autoSave;
  ThemeMode get themeMode => _isDarkMode ? ThemeMode.dark : ThemeMode.light;

  Future<void> toggleDarkMode() async {
    _isDarkMode = !_isDarkMode;
    await _prefs.setBool(AppConstants.prefDarkMode, _isDarkMode);
    notifyListeners();
  }

  Future<void> setDarkMode(bool value) async {
    _isDarkMode = value;
    await _prefs.setBool(AppConstants.prefDarkMode, value);
    notifyListeners();
  }

  Future<void> toggleAutoSave() async {
    _autoSave = !_autoSave;
    await _prefs.setBool(AppConstants.prefAutoSave, _autoSave);
    notifyListeners();
  }

  Future<void> setAutoSave(bool value) async {
    _autoSave = value;
    await _prefs.setBool(AppConstants.prefAutoSave, value);
    notifyListeners();
  }
}
