import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'constants.dart';

class FileUtils {
  FileUtils._();

  // Fix: MethodChannel for Android MediaStore scan — no extra plugin needed
  static const _mediaChannel = MethodChannel('com.yourname.statussaver/media');

  /// Creates the save directory if it doesn't exist.
  static Future<Directory> getSaveDirectory() async {
    final dir = Directory(AppConstants.savePath);
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  /// Save a status file to Pictures/StatusSaver.
  static Future<String?> saveStatus(String sourcePath) async {
    try {
      final sourceFile = File(sourcePath);

      if (!await sourceFile.exists()) {
        if (kDebugMode) print('Source file does not exist: $sourcePath');
        return null;
      }

      final saveDir = await getSaveDirectory();
      final fileName = sourcePath.split('/').last;
      final destPath = '${saveDir.path}/$fileName';

      // Already saved — return existing path
      if (await File(destPath).exists()) {
        return destPath;
      }

      final savedFile = await sourceFile.copy(destPath);

      // Fix: Notify media scanner via MethodChannel so gallery sees file immediately.
      // Falls back silently if the channel isn't registered (e.g. on iOS / unit tests).
      await _scanFile(savedFile.path);

      return savedFile.path;
    } catch (e) {
      if (kDebugMode) print('Error saving status: $e');
      return null;
    }
  }

  /// Asks Android to add the file to the MediaStore.
  /// This is a best-effort call — failure is non-fatal.
  static Future<void> _scanFile(String filePath) async {
    try {
      await _mediaChannel.invokeMethod<void>('scanFile', {'path': filePath});
    } on MissingPluginException {
      // Channel not registered yet — harmless, file is saved on disk
      if (kDebugMode) print('MediaScanner channel not available, skipping scan');
    } catch (e) {
      if (kDebugMode) print('Media scan failed (non-fatal): $e');
    }
  }

  /// Delete a file from storage.
  static Future<bool> deleteFile(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        await file.delete();
        return true;
      }
      return false;
    } catch (e) {
      if (kDebugMode) print('Error deleting file: $e');
      return false;
    }
  }

  /// Get all saved statuses from the save directory.
  static Future<List<File>> getSavedFiles() async {
    try {
      final saveDir = await getSaveDirectory();
      if (!await saveDir.exists()) return [];

      final List<FileSystemEntity> entities;
      try {
        entities = saveDir.listSync(followLinks: false);
      } on FileSystemException catch (e) {
        if (kDebugMode) print('Permission denied reading save dir: $e');
        return [];
      }

      final files = entities
          .whereType<File>()
          .where((f) {
            final lower = f.path.toLowerCase();
            return AppConstants.imageExtensions.any((ext) => lower.endsWith(ext)) ||
                AppConstants.videoExtensions.any((ext) => lower.endsWith(ext));
          })
          .toList();

      files.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
      return files;
    } catch (e) {
      if (kDebugMode) print('Error getting saved files: $e');
      return [];
    }
  }

  /// Get files from a WhatsApp status directory.
  static Future<List<File>> getWhatsAppStatusFiles(String dirPath) async {
    try {
      final dir = Directory(dirPath);
      if (!await dir.exists()) return [];

      final List<FileSystemEntity> entities;
      try {
        entities = dir.listSync(followLinks: false);
      } on FileSystemException catch (e) {
        if (kDebugMode) print('Permission denied or IO error reading $dirPath: $e');
        return [];
      }

      final files = entities
          .whereType<File>()
          .where((f) {
            if (f.path.endsWith('.nomedia')) return false;
            final lower = f.path.toLowerCase();
            return AppConstants.imageExtensions.any((ext) => lower.endsWith(ext)) ||
                AppConstants.videoExtensions.any((ext) => lower.endsWith(ext));
          })
          .toList();

      files.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
      return files;
    } on FileSystemException catch (e) {
      if (kDebugMode) print('FileSystemException for $dirPath: $e');
      return [];
    } catch (e) {
      if (kDebugMode) print('Error reading WA status dir: $e');
      return [];
    }
  }

  /// Check if a status is already saved.
  static Future<bool> isAlreadySaved(String sourcePath) async {
    final fileName = sourcePath.split('/').last;
    final destPath = '${AppConstants.savePath}/$fileName';
    return File(destPath).exists();
  }

  static String getFileSize(String filePath) {
    try {
      final bytes = File(filePath).lengthSync();
      if (bytes < 1024) return '${bytes}B';
      if (bytes < 1048576) return '${(bytes / 1024).toStringAsFixed(1)}KB';
      return '${(bytes / 1048576).toStringAsFixed(1)}MB';
    } catch (_) {
      return '';
    }
  }

  static bool isVideo(String path) {
    final lower = path.toLowerCase();
    return AppConstants.videoExtensions.any((ext) => lower.endsWith(ext));
  }

  static bool isImage(String path) {
    final lower = path.toLowerCase();
    return AppConstants.imageExtensions.any((ext) => lower.endsWith(ext));
  }
}
