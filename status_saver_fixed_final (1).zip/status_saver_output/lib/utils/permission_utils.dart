import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';

class PermissionUtils {
  PermissionUtils._();

  static int? _cachedSdkInt;

  /// Returns the Android SDK version integer (e.g. 33 for Android 13).
  /// Cached after first call.
  static Future<int> _androidSdkVersion() async {
    if (_cachedSdkInt != null) return _cachedSdkInt!;
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      _cachedSdkInt = info.version.sdkInt;
    } catch (e) {
      if (kDebugMode) print('[PermissionUtils] DeviceInfo error: $e');
      _cachedSdkInt = 0;
    }
    return _cachedSdkInt!;
  }

  /// Request all required storage permissions based on the real Android SDK version.
  /// Returns true only if all required permissions are granted.
  static Future<bool> requestStoragePermission() async {
    if (!Platform.isAndroid) return true;

    try {
      final sdk = await _androidSdkVersion();

      if (sdk >= 33) {
        // Android 13+ — granular media permissions
        final results = await [
          Permission.photos,
          Permission.videos,
        ].request();

        final photos = results[Permission.photos];
        final videos = results[Permission.videos];
        final granted = (photos?.isGranted ?? false) && (videos?.isGranted ?? false);

        if (kDebugMode) {
          print('[PermissionUtils] SDK $sdk | photos=$photos | videos=$videos | granted=$granted');
        }
        return granted;
      } else {
        // Android < 13 — READ_EXTERNAL_STORAGE
        final result = await Permission.storage.request();
        if (kDebugMode) {
          print('[PermissionUtils] SDK $sdk | storage=$result');
        }
        return result.isGranted;
      }
    } catch (e) {
      if (kDebugMode) print('[PermissionUtils] Request error: $e');
      return false;
    }
  }

  /// Check if storage permission is already granted (no dialog shown).
  static Future<bool> hasStoragePermission() async {
    if (!Platform.isAndroid) return true;

    try {
      final sdk = await _androidSdkVersion();

      if (sdk >= 33) {
        return await Permission.photos.isGranted &&
            await Permission.videos.isGranted;
      } else {
        return await Permission.storage.isGranted;
      }
    } catch (e) {
      if (kDebugMode) print('[PermissionUtils] Check error: $e');
      return false;
    }
  }

  /// Returns true if any required permission is permanently denied.
  /// In this case the user must open settings manually.
  static Future<bool> isPermanentlyDenied() async {
    if (!Platform.isAndroid) return false;

    try {
      final sdk = await _androidSdkVersion();

      if (sdk >= 33) {
        return await Permission.photos.isPermanentlyDenied ||
            await Permission.videos.isPermanentlyDenied;
      } else {
        return await Permission.storage.isPermanentlyDenied;
      }
    } catch (e) {
      if (kDebugMode) print('[PermissionUtils] isPermanentlyDenied error: $e');
      return false;
    }
  }

  /// Open app settings so the user can manually grant permission.
  static Future<void> openSettings() async {
    await openAppSettings();
  }
}
