class AppConstants {
  // App Info
  static const String appName = 'Status Saver';
  static const String appVersion = '1.0.0';
  // TODO: Replace with your real package name before publishing
  static const String packageName = 'com.yourname.statussaver';
  // TODO: Replace with your real Play Store URL after publishing
  static const String playStoreUrl =
      'https://play.google.com/store/apps/details?id=com.yourname.statussaver';
  // TODO: Replace with your real hosted privacy policy URL (required by Play Store)
  static const String privacyPolicyUrl =
      'https://yourwebsite.com/privacy-policy';

  // WhatsApp Status Paths — both legacy and Android 11+ scoped storage paths
  // Fix: Added fallback paths for newer WhatsApp versions
  static const List<String> whatsappStatusPaths = [
    '/storage/emulated/0/WhatsApp/Media/.Statuses',
    '/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/.Statuses',
  ];
  static const List<String> whatsappBusinessStatusPaths = [
    '/storage/emulated/0/WhatsApp Business/Media/.Statuses',
    '/storage/emulated/0/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses',
  ];

  // Save Directory
  static const String saveFolderName = 'StatusSaver';
  static const String savePath =
      '/storage/emulated/0/Pictures/StatusSaver';

  // AdMob IDs
  // TODO: Replace ALL of these with your REAL AdMob IDs before publishing.
  // Using test IDs in production violates AdMob policy and earns $0.
  // Get real IDs from: https://apps.admob.com
  static const String admobAppId =
      'ca-app-pub-3940256099942544~3347511713'; // TEST ID
  static const String bannerAdUnitId =
      'ca-app-pub-3940256099942544/6300978111'; // TEST ID
  static const String interstitialAdUnitId =
      'ca-app-pub-3940256099942544/1033173712'; // TEST ID
  static const String rewardedAdUnitId =
      'ca-app-pub-3940256099942544/5224354917'; // TEST ID
  static const String nativeAdUnitId =
      'ca-app-pub-3940256099942544/2247696110'; // TEST ID
  static const String appOpenAdUnitId =
      'ca-app-pub-3940256099942544/9257395921'; // TEST ID

  // Ad Settings
  static const int interstitialShowAfter = 3;
  static const int nativeAdEveryN = 6;
  static const int appOpenAdCooldownHours = 4;

  // SharedPreferences Keys
  static const String prefDarkMode = 'dark_mode';
  static const String prefAutoSave = 'auto_save';
  static const String prefLastAppOpenAd = 'last_app_open_ad';

  // File Extensions
  static const List<String> imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
  static const List<String> videoExtensions = ['.mp4', '.mkv', '.avi', '.mov', '.3gp'];
}
