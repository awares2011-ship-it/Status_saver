import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'constants.dart';

/// Fix: AdManager now listens to the app lifecycle so App Open Ads are only
/// shown when the app genuinely comes to the foreground — not during in-app
/// navigation transitions.
class AdManager with WidgetsBindingObserver {
  AdManager._internal();
  static final AdManager _instance = AdManager._internal();
  static AdManager get instance => _instance;

  // Ad objects
  BannerAd? _homeBannerAd;
  BannerAd? _savedBannerAd;
  InterstitialAd? _interstitialAd;
  AppOpenAd? _appOpenAd;

  // State
  bool _isHomeBannerLoaded = false;
  bool _isSavedBannerLoaded = false;
  bool _isInterstitialLoaded = false;
  bool _isAppOpenAdAvailable = false;
  bool _isShowingAppOpenAd = false;
  bool _isShowingFullScreenAd = false; // tracks interstitial too
  int _downloadCounter = 0;
  bool _initialised = false;

  // Getters
  BannerAd? get homeBannerAd => _homeBannerAd;
  BannerAd? get savedBannerAd => _savedBannerAd;
  bool get isHomeBannerLoaded => _isHomeBannerLoaded;
  bool get isSavedBannerLoaded => _isSavedBannerLoaded;

  void initialize() {
    if (_initialised) return;
    _initialised = true;
    // Fix: register lifecycle observer for App Open Ad
    WidgetsBinding.instance.addObserver(this);
    loadInterstitial();
    loadAppOpenAd();
  }

  // ─── APP LIFECYCLE ────────────────────────────────────────────────────────

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Fix: only show App Open Ad when app resumes from background,
    // never during in-app transitions
    if (state == AppLifecycleState.resumed && !_isShowingFullScreenAd) {
      showAppOpenAd();
    }
  }

  // ─── BANNER ADS ───────────────────────────────────────────────────────────

  void loadHomeBanner({VoidCallback? onLoaded}) {
    _homeBannerAd?.dispose();
    _isHomeBannerLoaded = false;
    _homeBannerAd = BannerAd(
      adUnitId: AppConstants.bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          _isHomeBannerLoaded = true;
          onLoaded?.call();
          if (kDebugMode) print('Home Banner loaded');
        },
        onAdFailedToLoad: (ad, error) {
          _isHomeBannerLoaded = false;
          ad.dispose();
          _homeBannerAd = null;
          if (kDebugMode) print('Home Banner failed: $error');
        },
      ),
    );
    _homeBannerAd!.load();
  }

  void loadSavedBanner({VoidCallback? onLoaded}) {
    _savedBannerAd?.dispose();
    _isSavedBannerLoaded = false;
    _savedBannerAd = BannerAd(
      adUnitId: AppConstants.bannerAdUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          _isSavedBannerLoaded = true;
          onLoaded?.call();
          if (kDebugMode) print('Saved Banner loaded');
        },
        onAdFailedToLoad: (ad, error) {
          _isSavedBannerLoaded = false;
          ad.dispose();
          _savedBannerAd = null;
          if (kDebugMode) print('Saved Banner failed: $error');
        },
      ),
    );
    _savedBannerAd!.load();
  }

  void disposeHomeBanner() {
    _homeBannerAd?.dispose();
    _homeBannerAd = null;
    _isHomeBannerLoaded = false;
  }

  void disposeSavedBanner() {
    _savedBannerAd?.dispose();
    _savedBannerAd = null;
    _isSavedBannerLoaded = false;
  }

  // ─── INTERSTITIAL AD ──────────────────────────────────────────────────────

  void loadInterstitial() {
    InterstitialAd.load(
      adUnitId: AppConstants.interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _interstitialAd = ad;
          _isInterstitialLoaded = true;
          _interstitialAd!.setImmersiveMode(true);
          if (kDebugMode) print('Interstitial loaded');
        },
        onAdFailedToLoad: (error) {
          _isInterstitialLoaded = false;
          _interstitialAd = null;
          if (kDebugMode) print('Interstitial failed: $error');
          Future.delayed(const Duration(seconds: 30), loadInterstitial);
        },
      ),
    );
  }

  /// Call on every download action. Shows interstitial every N downloads.
  void onDownloadAction() {
    _downloadCounter++;
    if (_downloadCounter >= AppConstants.interstitialShowAfter) {
      _downloadCounter = 0;
      showInterstitial();
    }
  }

  void showInterstitial({VoidCallback? onDismissed}) {
    if (!_isInterstitialLoaded || _interstitialAd == null) {
      onDismissed?.call();
      return;
    }
    _isShowingFullScreenAd = true;
    _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        _isShowingFullScreenAd = false;
        ad.dispose();
        _interstitialAd = null;
        _isInterstitialLoaded = false;
        loadInterstitial();
        onDismissed?.call();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        _isShowingFullScreenAd = false;
        ad.dispose();
        _interstitialAd = null;
        _isInterstitialLoaded = false;
        loadInterstitial();
        onDismissed?.call();
        if (kDebugMode) print('Interstitial show failed: $error');
      },
    );
    _interstitialAd!.show();
  }

  // ─── NATIVE AD ────────────────────────────────────────────────────────────

  NativeAd createNativeAd({required NativeAdListener listener}) {
    return NativeAd(
      adUnitId: AppConstants.nativeAdUnitId,
      factoryId: 'listTile',
      request: const AdRequest(),
      listener: listener,
    );
  }

  // ─── APP OPEN AD ──────────────────────────────────────────────────────────

  void loadAppOpenAd() {
    AppOpenAd.load(
      adUnitId: AppConstants.appOpenAdUnitId,
      request: const AdRequest(),
      adLoadCallback: AppOpenAdLoadCallback(
        onAdLoaded: (ad) {
          _appOpenAd = ad;
          _isAppOpenAdAvailable = true;
          if (kDebugMode) print('App Open Ad loaded');
        },
        onAdFailedToLoad: (error) {
          _isAppOpenAdAvailable = false;
          _appOpenAd = null;
          if (kDebugMode) print('App Open Ad failed: $error');
        },
      ),
    );
  }

  /// Fix: checks lifecycle guard (_isShowingFullScreenAd) before showing,
  /// so the ad is never triggered by in-app transitions.
  Future<void> showAppOpenAd() async {
    if (!_isAppOpenAdAvailable ||
        _appOpenAd == null ||
        _isShowingAppOpenAd ||
        _isShowingFullScreenAd) {
      return;
    }

    // Cooldown check
    final prefs = await SharedPreferences.getInstance();
    final lastShown = prefs.getInt(AppConstants.prefLastAppOpenAd) ?? 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    final cooldown = AppConstants.appOpenAdCooldownHours * 60 * 60 * 1000;

    if (now - lastShown < cooldown) {
      if (kDebugMode) print('App Open Ad on cooldown');
      return;
    }

    _isShowingAppOpenAd = true;
    _isShowingFullScreenAd = true;
    _appOpenAd!.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        _isShowingAppOpenAd = false;
        _isShowingFullScreenAd = false;
        ad.dispose();
        _appOpenAd = null;
        _isAppOpenAdAvailable = false;
        loadAppOpenAd();
        prefs.setInt(AppConstants.prefLastAppOpenAd,
            DateTime.now().millisecondsSinceEpoch);
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        _isShowingAppOpenAd = false;
        _isShowingFullScreenAd = false;
        ad.dispose();
        _appOpenAd = null;
        _isAppOpenAdAvailable = false;
        loadAppOpenAd();
        if (kDebugMode) print('App Open Ad show failed: $error');
      },
    );
    _appOpenAd!.show();
  }

  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _homeBannerAd?.dispose();
    _savedBannerAd?.dispose();
    _interstitialAd?.dispose();
    _appOpenAd?.dispose();
  }
}
