# ─── Flutter core ─────────────────────────────────────────────────────────────
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }
-keep class io.flutter.embedding.** { *; }
-dontwarn io.flutter.**

# ─── App classes ──────────────────────────────────────────────────────────────
-keep class com.yourname.statussaver.** { *; }

# ─── Google Mobile Ads / AdMob ────────────────────────────────────────────────
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.android.gms.ads.nativead.** { *; }
-keep class com.google.ads.** { *; }
-dontwarn com.google.android.gms.**
-keep public class com.google.android.gms.common.internal.safeparcel.SafeParcelable {
    public static final *** NULL;
}
# Required for AdMob native ad factory
-keepclassmembers class * implements io.flutter.plugins.googlemobileads.GoogleMobileAdsPlugin$NativeAdFactory {
    *;
}

# ─── permission_handler ───────────────────────────────────────────────────────
-keep class com.baseflow.permissionhandler.** { *; }
-dontwarn com.baseflow.permissionhandler.**

# ─── photo_manager ────────────────────────────────────────────────────────────
-keep class com.fluttercandies.photo_manager.** { *; }
-dontwarn com.fluttercandies.photo_manager.**

# ─── video_player / ExoPlayer ─────────────────────────────────────────────────
-keep class io.flutter.plugins.videoplayer.** { *; }
-keep class com.google.android.exoplayer2.** { *; }
-dontwarn com.google.android.exoplayer2.**
# ExoPlayer extension decoders (keep if bundled)
-keep class com.google.android.exoplayer2.ext.** { *; }
-keep class com.google.android.exoplayer2.video.spherical.** { *; }

# ─── share_plus ───────────────────────────────────────────────────────────────
-keep class dev.fluttercommunity.plus.share.** { *; }
-dontwarn dev.fluttercommunity.plus.share.**

# ─── url_launcher ─────────────────────────────────────────────────────────────
-keep class io.flutter.plugins.urllauncher.** { *; }
-dontwarn io.flutter.plugins.urllauncher.**

# ─── path_provider ────────────────────────────────────────────────────────────
-keep class io.flutter.plugins.pathprovider.** { *; }

# ─── shared_preferences ───────────────────────────────────────────────────────
-keep class io.flutter.plugins.sharedpreferences.** { *; }

# ─── device_info_plus ─────────────────────────────────────────────────────────
-keep class dev.fluttercommunity.plus.device_info.** { *; }
-dontwarn dev.fluttercommunity.plus.device_info.**

# ─── Kotlin / Coroutines ──────────────────────────────────────────────────────
-keep class kotlin.** { *; }
-keep class kotlin.Metadata { *; }
-dontwarn kotlin.**
-keep class kotlinx.coroutines.** { *; }
-dontwarn kotlinx.coroutines.**

# ─── AndroidX ─────────────────────────────────────────────────────────────────
-keep class androidx.** { *; }
-dontwarn androidx.**

# ─── General safety net ───────────────────────────────────────────────────────
# Keep all Parcelable implementations (needed for Android IPC)
-keep class * implements android.os.Parcelable { *; }
# Keep all Serializable implementations
-keep class * implements java.io.Serializable { *; }
# Keep R class fields (resources referenced by name)
-keepclassmembers class **.R$* { public static <fields>; }
